/*
 * CIG20 / PT6393-style alphanumeric VFD controller.
 *
 * Protocol and RAM layout recovered from the Tiger One Billion V1 Android
 * dvbstack implementation (gs_fpanel_construct_cig20 / PT6393_*):
 *   - 4-wire software SPI, LSB first, ~10 kHz
 *   - command 0x40 followed by RAM address 0xC0 + slot*3
 *   - 13 RAM slots, 3 bytes per slot: segment_lo, segment_hi, 0x00
 *   - text occupies slots 1..11; slots 0 and 12 are kept for status/icons
 *   - key read command 0x42 returns five bytes
 *   - display control is prefixed by 0x09
 */
#include <linux/string.h>
#include <linux/kernel.h>
#include "../protocols/spi_sw.h"
#include "cig20.h"

#define CIG20_TEXT_CHARS       11
#define CIG20_RAM_SLOTS        13
#define CIG20_SCROLL_GAP       3
#define CIG20_CMD_DATA_AUTO    0x40
#define CIG20_CMD_KEY_READ     0x42
#define CIG20_CMD_STATUS       0x45
#define CIG20_CMD_DISPLAY_CTRL 0x09
#define CIG20_RAM_BASE         0xC0

static unsigned char cig20_init(void);
static unsigned short cig20_get_brightness_levels_count(void);
static unsigned short cig20_get_brightness_level(void);
static unsigned char cig20_set_brightness_level(unsigned short level);
static unsigned char cig20_get_power(void);
static void cig20_set_power(unsigned char state);
static void cig20_power_suspend(void) { cig20_set_power(0); }
static void cig20_power_resume(void) { cig20_set_power(1); }
static struct vfd_display *cig20_get_display_type(void);
static unsigned char cig20_set_display_type(struct vfd_display *display);
static void cig20_set_icon(const char *name, unsigned char state);
static size_t cig20_read_data(unsigned char *data, size_t length);
static size_t cig20_write_data(const unsigned char *data, size_t length);
static size_t cig20_write_display_data(const struct vfd_display_data *data);

static struct controller_interface cig20_interface = {
    .init = cig20_init,
    .get_brightness_levels_count = cig20_get_brightness_levels_count,
    .get_brightness_level = cig20_get_brightness_level,
    .set_brightness_level = cig20_set_brightness_level,
    .get_power = cig20_get_power,
    .set_power = cig20_set_power,
    .power_suspend = cig20_power_suspend,
    .power_resume = cig20_power_resume,
    .get_display_type = cig20_get_display_type,
    .set_display_type = cig20_set_display_type,
    .set_icon = cig20_set_icon,
    .read_data = cig20_read_data,
    .write_data = cig20_write_data,
    .write_display_data = cig20_write_display_data,
};

static struct vfd_dev *dev;
static struct protocol_interface *protocol;
static u16 cig20_ram[CIG20_RAM_SLOTS];
static char cig20_last_title[sizeof(((struct vfd_display_data *)0)->string_main)];
static unsigned int cig20_scroll_pos;

/*
 * Tiger CIG20 segment table recovered from dvbstack.  Android converts
 * lowercase to uppercase before the lookup, so only the printable punctuation,
 * digits and uppercase alphabet used by channel names are required here.
 */
static u16 cig20_char_to_segments(unsigned char ch)
{
    if (ch >= 'a' && ch <= 'z')
        ch -= ('a' - 'A');

    switch (ch) {
    case ' ': return 0x0000;
    case '!': return 0x0604;
    case '#': return 0x7ffe;
    case '$': return 0x4bd2;
    case '%': return 0x1818;
    case '&': return 0x562a;
    case '(': return 0x0408;
    case ')': return 0x1020;
    case '*': return 0x1db8;
    case '+': return 0x0990;
    case '-': return 0x0180;
    case '.': return 0x0400;
    case '/': return 0x1008;
    case '0': return 0x6246;
    case '1': return 0x0204;
    case '2': return 0x6186;
    case '3': return 0x4386;
    case '4': return 0x03c4;
    case '5': return 0x43c2;
    case '6': return 0x63c2;
    case '7': return 0x0206;
    case '8': return 0x63c6;
    case '9': return 0x43c6;
    case '<': return 0x0408;
    case '=': return 0x4002;
    case '>': return 0x1020;
    case '@': return 0x6e42;
    case 'A': return 0x23c6;
    case 'B': return 0x4b16;
    case 'C': return 0x6042;
    case 'D': return 0x4a16;
    case 'E': return 0x61c2;
    case 'F': return 0x21c2;
    case 'G': return 0x6342;
    case 'H': return 0x23c4;
    case 'I': return 0x4812;
    case 'J': return 0x4204;
    case 'K': return 0x24c8;
    case 'L': return 0x6040;
    case 'M': return 0x226c;
    case 'N': return 0x2664;
    case 'O': return 0x6246;
    case 'P': return 0x21c6;
    case 'Q': return 0x6646;
    case 'R': return 0x25c6;
    case 'S': return 0x43c2;
    case 'T': return 0x0812;
    case 'U': return 0x6244;
    case 'V': return 0x3048;
    case 'W': return 0x3644;
    case 'X': return 0x1428;
    case 'Y': return 0x43c4;
    case 'Z': return 0x500a;
    case '[': return 0x6042;
    case '\\': return 0x0420;
    case ']': return 0x4206;
    case '^': return 0x0060;
    case '_': return 0x4000;
    default: return 0x0000;
    }
}

static unsigned char cig20_brightness_command(void)
{
    /* Exact Tiger behavior: levels 0..3 -> 0x88..0x8B; 4+ -> 0x8F. */
    if (dev->brightness < 4)
        return (unsigned char)(0x88 + dev->brightness);
    return 0x8f;
}

static int cig20_send_display_control(unsigned char control)
{
    if (!protocol)
        return -1;
    if (protocol->write_byte(CIG20_CMD_DISPLAY_CTRL))
        return -1;
    return protocol->write_byte(control) ? -1 : 0;
}

static size_t cig20_update(void)
{
    unsigned char out[1 + CIG20_RAM_SLOTS * 3];
    unsigned int i;

    if (!protocol)
        return 0;

    out[0] = CIG20_RAM_BASE;
    for (i = 0; i < CIG20_RAM_SLOTS; i++) {
        out[1 + i * 3] = (unsigned char)(cig20_ram[i] & 0xff);
        out[2 + i * 3] = (unsigned char)((cig20_ram[i] >> 8) & 0xff);
        out[3 + i * 3] = 0x00;
    }

    if (protocol->write_byte(CIG20_CMD_DATA_AUTO))
        return 0;
    if (protocol->write_data(out, sizeof(out)))
        return 0;
    if (cig20_send_display_control(dev->power ? cig20_brightness_command() : 0x80))
        return 0;
    return CIG20_RAM_SLOTS;
}

static void cig20_clear_text_ram(void)
{
    unsigned int i;
    for (i = 1; i <= CIG20_TEXT_CHARS; i++)
        cig20_ram[i] &= 0x0001; /* Preserve Tiger's per-position status bit. */
}

static void cig20_render_fixed(const char *text)
{
    unsigned int i;
    size_t len;
    unsigned int start = 0;

    cig20_clear_text_ram();
    if (!text)
        return;

    len = strnlen(text, CIG20_TEXT_CHARS);
    if (len < CIG20_TEXT_CHARS)
        start = (CIG20_TEXT_CHARS - (unsigned int)len) / 2;

    for (i = 0; i < len && (start + i) < CIG20_TEXT_CHARS; i++) {
        u16 keep = cig20_ram[1 + start + i] & 0x0001;
        cig20_ram[1 + start + i] = keep | cig20_char_to_segments((unsigned char)text[i]);
    }
}

static void cig20_render_title(const char *title)
{
    char clean[sizeof(cig20_last_title)];
    size_t len, cycle;
    unsigned int i;

    if (!title)
        title = "";

    strlcpy(clean, title, sizeof(clean));
    for (i = 0; clean[i]; i++) {
        unsigned char c = (unsigned char)clean[i];
        if (c == '\r' || c == '\n' || c == '\t')
            clean[i] = ' ';
    }

    if (strncmp(clean, cig20_last_title, sizeof(cig20_last_title)) != 0) {
        strlcpy(cig20_last_title, clean, sizeof(cig20_last_title));
        cig20_scroll_pos = 0;
    }

    len = strnlen(cig20_last_title, sizeof(cig20_last_title));
    cig20_clear_text_ram();

    if (len <= CIG20_TEXT_CHARS) {
        cig20_render_fixed(cig20_last_title);
        return;
    }

    cycle = len + CIG20_SCROLL_GAP;
    for (i = 0; i < CIG20_TEXT_CHARS; i++) {
        size_t p = (cig20_scroll_pos + i) % cycle;
        unsigned char ch = (p < len) ? (unsigned char)cig20_last_title[p] : ' ';
        u16 keep = cig20_ram[1 + i] & 0x0001;
        cig20_ram[1 + i] = keep | cig20_char_to_segments(ch);
    }
    cig20_scroll_pos++;
    if (cig20_scroll_pos >= cycle)
        cig20_scroll_pos = 0;
}

static unsigned char cig20_init(void)
{
    unsigned char status_init[2] = { CIG20_CMD_STATUS, 0x82 };

    protocol = init_sw_spi_4w(LSB_FIRST,
                              dev->clk_pin,
                              dev->dat_pin,   /* host TX -> panel DIN */
                              dev->gpio0_pin, /* panel DOUT -> host RX */
                              dev->stb_pin,
                              SPI_DELAY_10KHz);
    if (!protocol)
        return 0;

    memset(cig20_ram, 0, sizeof(cig20_ram));
    memset(cig20_last_title, 0, sizeof(cig20_last_title));
    cig20_scroll_pos = 0;
    dev->brightness &= 0x07;
    dev->power = 1;

    /* Exact CIG20 startup sequence recovered from Tiger dvbstack. */
    if (cig20_send_display_control(0x8f))
        return 0;
    if (!cig20_update())
        return 0;
    if (protocol->write_data(status_init, sizeof(status_init)))
        return 0;

    pr_dbg2("CIG20/PT6393 initialized: 11 chars, 13 RAM slots, 4-wire LSB SPI @ ~10kHz\n");
    return 1;
}

static unsigned short cig20_get_brightness_levels_count(void)
{
    return 8;
}

static unsigned short cig20_get_brightness_level(void)
{
    return dev->brightness;
}

static unsigned char cig20_set_brightness_level(unsigned short level)
{
    dev->brightness = (unsigned char)(level & 0x07);
    dev->power = 1;
    return cig20_send_display_control(cig20_brightness_command()) == 0;
}

static unsigned char cig20_get_power(void)
{
    return dev->power;
}

static void cig20_set_power(unsigned char state)
{
    dev->power = state ? 1 : 0;
    /* 0x80 is the PT63xx display-off control; on uses Tiger brightness logic. */
    cig20_send_display_control(dev->power ? cig20_brightness_command() : 0x80);
}

static struct vfd_display *cig20_get_display_type(void)
{
    return &dev->dtb_active.display;
}

static unsigned char cig20_set_display_type(struct vfd_display *display)
{
    if (!display || display->controller != CONTROLLER_CIG20)
        return 0;
    dev->dtb_active.display = *display;
    return cig20_init();
}



/*
 * Tiger CIG20 signal meter recovered and hardware-verified on the
 * One Billion V1 glass.  The meter occupies bits 3..14 of RAM slot 12.
 * Keep the remaining slot-12 bits intact for any later-discovered icons.
 *
 * The original panel has six visible bar levels.  The thresholds below
 * intentionally match the hardware test utility that was verified on-box.
 */
unsigned char cig20_set_signal_percent(unsigned int percent)
{
    static const u16 signal_level[7] = {
        0x0000, 0x6000, 0x7800, 0x7e00,
        0x7f80, 0x7fe0, 0x7ff8
    };
    unsigned int level;
    const u16 mask = 0x7ff8;

    if (percent > 100)
        percent = 100;

    level = percent / 16;
    if (level > 6)
        level = 6;

    cig20_ram[12] = (cig20_ram[12] & ~mask) |
                    (signal_level[level] & mask);

    if (!cig20_update())
        return 0;

    pr_dbg2("CIG20 signal=%u%% level=%u slot12=0x%04x\\n",
            percent, level, cig20_ram[12]);
    return 1;
}

unsigned char cig20_set_status_mask(unsigned char mask)
{
    unsigned char cmd[2];

    if (!protocol)
        return 0;

    /* Tiger CIG20 has a separate one-byte status/icon register.
     * 0x80 is the fixed enable/base bit seen in the Android startup value
     * 0x82; bits 0..6 are scanned independently to discover glass icons. */
    cmd[0] = CIG20_CMD_STATUS;
    cmd[1] = (unsigned char)(0x80 | (mask & 0x7f));

    if (protocol->write_data(cmd, sizeof(cmd)))
        return 0;

    pr_dbg2("CIG20 status raw=0x%02x mask=0x%02x\n", cmd[1], mask & 0x7f);
    return 1;
}

static void cig20_set_icon(const char *name, unsigned char state)
{
    /*
     * Tiger has a separate CIG20 status/icon API, but icon names are product
     * specific.  Do not guess mappings here and risk overwriting glass icons.
     * Text RAM slots 0 and 12 stay untouched for a later verified icon map.
     */
    (void)name;
    (void)state;
}

static size_t cig20_read_data(unsigned char *data, size_t length)
{
    unsigned char cmd = CIG20_CMD_KEY_READ;
    size_t count;

    if (!protocol || !data || !length)
        return 0;
    count = min(length, (size_t)5);
    return protocol->read_cmd_data(&cmd, 1, data, (unsigned short)count) ? 0 : count;
}

static size_t cig20_write_data(const unsigned char *data, size_t length)
{
    size_t slots, i;

    if (!data || length < 2)
        return 0;

    slots = min(length / 2, (size_t)CIG20_RAM_SLOTS);
    for (i = 0; i < slots; i++)
        cig20_ram[i] = (u16)data[i * 2] | ((u16)data[i * 2 + 1] << 8);

    return cig20_update() ? slots * 2 : 0;
}

static size_t cig20_write_display_data(const struct vfd_display_data *data)
{
    char text[64];

    if (!data)
        return 0;

    switch (data->mode) {
    case DISPLAY_MODE_CLOCK:
        scnprintf(text, sizeof(text), "%02u%c%02u",
                  data->time_date.hours,
                  data->colon_on ? ':' : ' ',
                  data->time_date.minutes);
        cig20_render_fixed(text);
        break;
    case DISPLAY_MODE_CHANNEL:
        scnprintf(text, sizeof(text), "%04u", data->channel_data.channel);
        cig20_render_fixed(text);
        break;
    case DISPLAY_MODE_PLAYBACK_TIME:
        scnprintf(text, sizeof(text), "%02u %02u %02u",
                  data->time_secondary.hours,
                  data->time_secondary.minutes,
                  data->time_secondary.seconds);
        cig20_render_fixed(text);
        break;
    case DISPLAY_MODE_TITLE:
        cig20_render_title(data->string_main);
        break;
    case DISPLAY_MODE_TEMPERATURE:
        scnprintf(text, sizeof(text), "TEMP %uC", data->temperature);
        cig20_render_fixed(text);
        break;
    case DISPLAY_MODE_DATE:
        scnprintf(text, sizeof(text), "%02u-%02u-%04u",
                  data->time_date.day,
                  data->time_date.month + 1,
                  data->time_date.year);
        cig20_render_fixed(text);
        break;
    case DISPLAY_MODE_NONE:
    default:
        cig20_clear_text_ram();
        break;
    }

    return cig20_update() ? CIG20_TEXT_CHARS : 0;
}

struct controller_interface *init_cig20(struct vfd_dev *_dev)
{
    dev = _dev;
    return &cig20_interface;
}
