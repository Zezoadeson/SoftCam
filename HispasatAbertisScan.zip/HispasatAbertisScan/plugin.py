# -*- coding: utf-8 -*-
# Hispasat Abertis generic hidden-carrier scan helper + OSCam child-mux v6.2.2 profile-transition fix / single-profile replace save
# GPL-2.0-or-later

from __future__ import print_function

import os
import re
import time
import shutil

from enigma import (
    eComponentScan,
    eDVBFrontendParametersSatellite,
    eServiceReference,
    eTimer,
    eDVBDB,
)
from Screens.Screen import Screen
from Screens.ChoiceBox import ChoiceBox
from Screens.MessageBox import MessageBox
from Components.Label import Label
from Components.ProgressBar import ProgressBar
from Components.ActionMap import ActionMap
from Components.NimManager import nimmanager
from Plugins.Plugin import PluginDescriptor

from .abertis_config import PROFILES, ORBITAL_POSITION, carrier_values, find_carrier

try:
    from . import hidden_ca
except Exception:
    hidden_ca = None

PARAM_BASE = "/sys/module/aml_hardware_dmx/parameters"
PARAM_PID = PARAM_BASE + "/e2_abertis_force_pid"
PARAM_SID = PARAM_BASE + "/e2_abertis_force_sid"
PARAM_FORCE_ENABLE = PARAM_BASE + "/e2_abertis_force_enable"
PARAM_RUNTIME_MODE = PARAM_BASE + "/e2_abertis_runtime_mode"
PARAM_INNER_SID = PARAM_BASE + "/e2_abertis_child_inner_sid"
PARAM_HITS = PARAM_BASE + "/e2_abertis_hits"
PARAM_LAST_PID = PARAM_BASE + "/e2_abertis_last_pid"
PARAM_FORCE_READY = PARAM_BASE + "/e2_abertis_force_ready_hits"
PARAM_INNER = PARAM_BASE + "/e2_abertis_inner_packets"
PARAM_HOLD_ENABLE = PARAM_BASE + "/e2_abertis_helper_cw_hold"
PARAM_HOLD_PID = PARAM_BASE + "/e2_abertis_helper_hold_pid"
PARAM_HOLD_REUSES = PARAM_BASE + "/e2_abertis_helper_cw_reuses"
LOGFILE = "/tmp/hispasat_abertis_scan.log"
MAPFILE = "/etc/enigma2/hispasat_abertis_native.map"

def log(msg):
    line = time.strftime("%H:%M:%S") + " " + str(msg)
    print("[HispasatAbertisScan] " + line)
    try:
        with open(LOGFILE, "a") as f:
            f.write(line + "\n")
    except Exception:
        pass


def read_int(path, default=-1):
    try:
        with open(path, "r") as f:
            return int(f.read().strip(), 0)
    except Exception:
        return default


def write_param(path, value):
    with open(path, "w") as f:
        f.write(str(value))


def timer_connect(timer, fn):
    try:
        timer.callback.append(fn)
    except Exception:
        timer.timeout.connect(fn)


def find_dvbs_tuner():
    for slot in nimmanager.nim_slots:
        try:
            if slot.isCompatible("DVB-S") or slot.isCompatible("DVB-S2") or slot.isCompatible("DVB-S2X"):
                return int(slot.slot)
        except Exception:
            try:
                if slot.isCompatible("DVB-S"):
                    return int(slot.slot)
            except Exception:
                pass
    return -1


def build_satparm(profile):
    name, freq, sr, pol, carriers = profile
    p = eDVBFrontendParametersSatellite()
    p.frequency = int(freq)
    p.symbol_rate = int(sr)
    p.polarisation = (eDVBFrontendParametersSatellite.Polarisation_Horizontal
                      if pol == "H" else eDVBFrontendParametersSatellite.Polarisation_Vertical)
    p.fec = getattr(eDVBFrontendParametersSatellite, "FEC_Auto", 0)
    p.inversion = getattr(eDVBFrontendParametersSatellite, "Inversion_Unknown", 2)
    p.orbital_position = ORBITAL_POSITION
    p.system = getattr(eDVBFrontendParametersSatellite, "System_DVB_S2", 1)
    p.modulation = getattr(eDVBFrontendParametersSatellite, "Modulation_8PSK", 2)
    p.rolloff = getattr(eDVBFrontendParametersSatellite, "RollOff_alpha_0_35", 0)
    p.pilot = getattr(eDVBFrontendParametersSatellite, "Pilot_Unknown", 2)
    # Never request MIS/T2-MI through Enigma2 for Abertis hidden carriers.
    if hasattr(p, "is_id"):
        p.is_id = getattr(eDVBFrontendParametersSatellite, "No_Stream_Id_Filter", -1)
    if hasattr(p, "pls_mode"):
        p.pls_mode = getattr(eDVBFrontendParametersSatellite, "PLS_Gold", 1)
    if hasattr(p, "pls_code"):
        p.pls_code = getattr(eDVBFrontendParametersSatellite, "PLS_Default_Gold_Code", 0)
    if hasattr(p, "t2mi_plp_id"):
        p.t2mi_plp_id = getattr(eDVBFrontendParametersSatellite, "No_T2MI_PLP_Id", -1)
    if hasattr(p, "t2mi_pid"):
        p.t2mi_pid = getattr(eDVBFrontendParametersSatellite, "T2MI_Default_Pid", 4096)
    return p


def _parse_hex(s):
    try:
        return int(s, 16)
    except Exception:
        return None


def _sat_namespace_matches(ns):
    try:
        return ((int(ns) >> 16) & 0xffff) == ORBITAL_POSITION
    except Exception:
        return False


def _make_data_ref(source_sid, ns, tsid, onid):
    # The hidden Abertis source services are data services.  Type 0xC is the
    # same Enigma2 service-reference type used by the working Abertis/Astra
    # source-service method; the transponder tuple comes from lamedb itself.
    return "1:0:C:%X:%X:%X:%X:0:0:0:" % (
        int(source_sid), int(tsid), int(onid), int(ns))


def find_source_ref(source_sid, frequency):
    """Return an outer Abertis source reference for one hidden carrier.

    Prefer a real service already stored in lamedb.  If Enigma2 deliberately
    omits the data service from its service list, synthesize only the service
    reference while reusing the exact namespace/TSID/ONID of the physical RF
    transponder already present in lamedb.  No transponder identity is guessed.
    """
    path = "/etc/enigma2/lamedb"
    if not os.path.exists(path):
        return None
    try:
        with open(path, "r") as f:
            lines = [x.rstrip("\n") for x in f]
    except Exception:
        return None

    transponders = {}

    # lamedb4
    in_tp = False
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if line == "transponders":
            in_tp = True
            i += 1
            continue
        if in_tp and line == "end":
            in_tp = False
        if in_tp and re.match(r"^[0-9a-fA-F]+:[0-9a-fA-F]+:[0-9a-fA-F]+$", line):
            parts = line.split(":")
            if len(parts) == 3:
                ns = _parse_hex(parts[0]); tsid = _parse_hex(parts[1]); onid = _parse_hex(parts[2])
                if None not in (ns, tsid, onid) and i + 1 < len(lines):
                    par = lines[i + 1].strip()
                    m = re.search(r"\bs\s+([0-9]+):([0-9]+):", par)
                    if m:
                        transponders[(ns, tsid, onid)] = int(m.group(1))
            i += 1
        i += 1

    in_services = False
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if line == "services":
            in_services = True
            i += 1
            continue
        if in_services and line == "end":
            break
        if in_services:
            parts = line.split(":")
            if len(parts) >= 6:
                vals = [_parse_hex(x) for x in parts[:6]]
                if None not in vals:
                    sid, ns, tsid, onid, stype, flags = vals
                    f = transponders.get((ns, tsid, onid))
                    if sid == int(source_sid) and f is not None and abs(f - int(frequency)) <= 3000:
                        return "1:0:%X:%X:%X:%X:%X:0:0:0:" % (stype, sid, tsid, onid, ns)
        i += 1

    # lamedb5 transponders/services.  Merge with any v4 tuples so images that
    # keep compatibility sections are handled as well.
    for line in lines:
        if not line.startswith("t:"):
            continue
        left = line.split(",", 1)[0]
        lp = left.split(":")
        if len(lp) < 4:
            continue
        ns = _parse_hex(lp[1]); tsid = _parse_hex(lp[2]); onid = _parse_hex(lp[3])
        if None in (ns, tsid, onid):
            continue
        m = re.search(r"(?:^|,)s:([0-9]+):([0-9]+):", line)
        if m:
            transponders[(ns, tsid, onid)] = int(m.group(1))

    for line in lines:
        if not line.startswith("s:"):
            continue
        left = line.split(",", 1)[0]
        q = left.split(":")
        if len(q) < 7:
            continue
        vals = [_parse_hex(x) for x in q[1:7]]
        if None in vals:
            continue
        sid, ns, tsid, onid, stype, flags = vals
        f = transponders.get((ns, tsid, onid))
        if sid == int(source_sid) and f is not None and abs(f - int(frequency)) <= 3000:
            return "1:0:%X:%X:%X:%X:%X:0:0:0:" % (stype, sid, tsid, onid, ns)

    # The data SID can be intentionally absent from lamedb.  Reuse the exact
    # physical transponder identity and construct only the data-service ref.
    candidates = []
    for (ns, tsid, onid), f in transponders.items():
        if abs(f - int(frequency)) <= 3000:
            candidates.append((0 if _sat_namespace_matches(ns) else 1, ns, tsid, onid, f))
    if candidates:
        candidates.sort()
        _, ns, tsid, onid, f = candidates[0]
        ref = _make_data_ref(source_sid, ns, tsid, onid)
        log("source SID %d absent from lamedb; synthetic data ref from physical TP ns=%X tsid=%X onid=%X freq=%d" %
            (source_sid, ns, tsid, onid, f))
        return ref
    return None


def _service_ref_parts(refstr):
    """Parse a normal DVB service reference into numeric identity fields."""
    try:
        parts = str(refstr).split(":")
        if len(parts) < 7 or parts[0] != "1":
            return None
        return {
            "stype": int(parts[2], 16),
            "sid": int(parts[3], 16),
            "tsid": int(parts[4], 16),
            "onid": int(parts[5], 16),
            "ns": int(parts[6], 16),
        }
    except Exception:
        return None


def _safe_service_name(name):
    try:
        name = str(name or "").replace("\\n", " ").replace("\\r", " ")
    except Exception:
        name = ""
    return name.strip() or "Abertis service"


def _lamedb_path():
    # This image family normally uses /etc/enigma2/lamedb.  Accept lamedb5
    # too so the helper does not silently fail on an image configured for v5.
    for path in ("/etc/enigma2/lamedb", "/etc/enigma2/lamedb5"):
        if os.path.exists(path):
            return path
    return "/etc/enigma2/lamedb"


def _find_rf_params_v4(lines, frequency, symbol_rate):
    for line in lines:
        q = line.strip()
        if not q.startswith("s "):
            continue
        vals = q[2:].split(":")
        try:
            if abs(int(vals[0]) - int(frequency)) <= 3000 and abs(int(vals[1]) - int(symbol_rate)) <= 3000:
                return q
        except Exception:
            pass
    return None


def _find_rf_params_v5(lines, frequency, symbol_rate):
    for line in lines:
        if not line.startswith("t:") or ",s:" not in line:
            continue
        tail = line.split(",", 1)[1].strip()
        vals = tail[2:].split(":") if tail.startswith("s:") else []
        try:
            if abs(int(vals[0]) - int(frequency)) <= 3000 and abs(int(vals[1]) - int(symbol_rate)) <= 3000:
                return tail
        except Exception:
            pass
    return None


def _ref_string(ref):
    try:
        return ref.toString()
    except Exception:
        try:
            return str(ref)
        except Exception:
            return ""


class AbertisScanRunner(Screen):
    skin = """
    <screen name="AbertisScanRunner" position="center,center" size="980,340" title="Hispasat Abertis Scan">
        <widget name="status" position="35,35" size="910,120" font="Regular;27" />
        <widget name="detail" position="35,165" size="910,70" font="Regular;22" />
        <widget name="progress" position="35,250" size="910,28" />
        <widget name="hint" position="35,295" size="910,30" font="Regular;19" />
    </screen>
    """

    def __init__(self, session, mode):
        Screen.__init__(self, session)
        self["status"] = Label("Preparing Hispasat Abertis scan...")
        self["detail"] = Label("")
        self["progress"] = ProgressBar()
        self["hint"] = Label("EXIT: cancel and restore normal automatic Abertis mode")
        self["actions"] = ActionMap(["OkCancelActions"], {"cancel": self.cancel}, -1)

        self.mode = mode
        self.queue = self._make_queue(mode)
        self.index = 0
        self.scan = None
        self.scan_pid = -1
        self.scan_hits_before = 0
        self.scan_retry = 0
        self.scan_had_source = False
        self.bootstrap_scan = False
        self.source_hits_before = 0
        self.source_ready_before = 0
        self.source_wait_deadline = 0
        self.post_verify_deadline = 0
        self.post_verify_info = None
        self.cancelled = False
        self.timer = eTimer()
        timer_connect(self.timer, self._timer_fired)
        self.pending_action = None
        self.saved_service = session.nav.getCurrentlyPlayingServiceOrGroup()
        self.saved_pid = read_int(PARAM_PID, -1)
        self.saved_sid = read_int(PARAM_SID, -1)
        self.saved_force_enable = read_int(PARAM_FORCE_ENABLE, 0)
        self.saved_runtime_mode = read_int(PARAM_RUNTIME_MODE, 0)
        self.saved_inner_sid = read_int(PARAM_INNER_SID, -1)
        self.saved_hold_enable = read_int(PARAM_HOLD_ENABLE, 0)
        self.saved_hold_pid = read_int(PARAM_HOLD_PID, -1)
        self.feid = find_dvbs_tuner()
        self.results = []
        self.scan_found_services = []
        self.all_found_services = []
        self.committed_services = []
        self.service_carrier_meta = {}
        self.service_carrier_ambiguous = set()
        self.lamedb_backup = None
        # Single-frequency replace mode: remember which profile this run owns
        # and which refs belonged to its previous scan.  They are removed from
        # this profile only; unrelated profile results stay untouched.
        self.selected_profile_name = mode.split(":", 1)[1] if mode.startswith("profile:") else None
        self.previous_profile_refs = set()
        self.previous_profile_service_keys = set()
        self.profile_lamedb_backup = None
        self.profile_lamedb_cleaned = False
        self.finished_successfully = False
        # v6.2.2: remember the RF profile whose source service was last
        # activated.  The first carrier of EVERY new RF profile gets the same
        # clean stop -> settle -> reacquire sequence that previously happened
        # only once at the beginning of the whole run.
        self.last_source_profile = None
        self.onShown.append(self._start_once)
        self._started = False

    def _normalize_ref(self, refstr):
        refstr = str(refstr or "").strip()
        parts = refstr.split(":")
        if len(parts) >= 10 and parts[0] == "1":
            return ":".join(parts[:10]) + ":"
        return refstr

    def _load_accumulated_map_rows(self):
        rows = {}
        try:
            if os.path.exists(MAPFILE):
                with open(MAPFILE, "r") as f:
                    for raw in f:
                        line = raw.rstrip("\n")
                        if not line or line.startswith("#"):
                            continue
                        cols = line.split("\t", 5)
                        if len(cols) < 6:
                            continue
                        refstr = self._normalize_ref(cols[0])
                        try:
                            rows[refstr] = (int(cols[1]), str(cols[2]), int(cols[3]),
                                            int(cols[4]), str(cols[5]))
                        except Exception:
                            continue
        except Exception as e:
            log("mapping load failed %s: %s" % (MAPFILE, e))
        return rows

    def _capture_previous_profile_refs(self):
        self.previous_profile_refs = set()
        self.previous_profile_service_keys = set()
        if not self.selected_profile_name:
            return
        rows = self._load_accumulated_map_rows()
        for refstr, row in rows.items():
            if len(row) < 2 or str(row[1]) != str(self.selected_profile_name):
                continue
            refstr = self._normalize_ref(refstr)
            self.previous_profile_refs.add(refstr)
            ident = _service_ref_parts(refstr)
            if ident:
                self.previous_profile_service_keys.add(
                    (ident["sid"], ident["ns"], ident["tsid"], ident["onid"]))
        log("profile replace capture %s old_refs=%d old_service_keys=%d" %
            (self.selected_profile_name, len(self.previous_profile_refs),
             len(self.previous_profile_service_keys)))

    def _remove_previous_profile_from_lamedb(self):
        """Remove only the inner services owned by the selected profile.

        The outer/source data services are not in hispasat_abertis_native.map,
        so they are never touched.  Orphan inner transponder records are pruned
        only when no remaining service still references that transport.
        """
        keys = set(self.previous_profile_service_keys)
        if not keys:
            return True
        path = _lamedb_path()
        try:
            with open(path, "r") as f:
                lines = [x.rstrip("\n") for x in f]
        except Exception as e:
            log("profile replace cannot read %s: %s" % (path, e))
            return False
        if not lines:
            return False

        try:
            backup = path + ".abertis-before-profile-rescan"
            shutil.copy2(path, backup)
            self.profile_lamedb_backup = backup
        except Exception as e:
            log("profile replace backup failed %s: %s" % (path, e))
            return False

        removed_services = 0
        removed_tps = 0
        removed_tpkeys = set((ns, tsid, onid) for sid, ns, tsid, onid in keys)
        is_v5 = "/5/" in lines[0].strip()

        if is_v5:
            kept = []
            remaining_tpkeys = set()
            for line in lines:
                if line.startswith("s:"):
                    head = line.split(",", 1)[0].split(":")
                    try:
                        k = (int(head[1], 16), int(head[2], 16),
                             int(head[3], 16), int(head[4], 16))
                    except Exception:
                        k = None
                    if k in keys:
                        removed_services += 1
                        continue
                    if k:
                        remaining_tpkeys.add((k[1], k[2], k[3]))
                kept.append(line)
            out = []
            for line in kept:
                if line.startswith("t:"):
                    head = line.split(",", 1)[0].split(":")
                    try:
                        tpk = (int(head[1], 16), int(head[2], 16), int(head[3], 16))
                    except Exception:
                        tpk = None
                    if tpk in removed_tpkeys and tpk not in remaining_tpkeys:
                        removed_tps += 1
                        continue
                out.append(line)
        else:
            try:
                svc_start = next(i for i, x in enumerate(lines) if x.strip() == "services")
                svc_end = next(i for i in range(svc_start + 1, len(lines)) if lines[i].strip() == "end")
            except Exception as e:
                log("profile replace cannot locate v4 services section: %s" % e)
                return False

            new_services = []
            remaining_tpkeys = set()
            i = svc_start + 1
            while i < svc_end:
                line = lines[i]
                parts = line.strip().split(":")
                if len(parts) >= 4:
                    try:
                        k = (int(parts[0], 16), int(parts[1], 16),
                             int(parts[2], 16), int(parts[3], 16))
                    except Exception:
                        k = None
                    # Normal lamedb4 service records are 3 lines: identity,
                    # name and provider/cache line.
                    rec = lines[i:min(i + 3, svc_end)]
                    if k in keys:
                        removed_services += 1
                        i += len(rec)
                        continue
                    if k:
                        remaining_tpkeys.add((k[1], k[2], k[3]))
                    new_services.extend(rec)
                    i += len(rec)
                    continue
                new_services.append(line)
                i += 1

            before_services = lines[:svc_start + 1]
            after_services = lines[svc_end:]

            # Safely prune only orphan transport records belonging exclusively
            # to the removed inner services.
            try:
                tp_start = next(i for i, x in enumerate(before_services) if x.strip() == "transponders")
                tp_end = next(i for i in range(tp_start + 1, len(before_services))
                              if before_services[i].strip() == "end")
                prefix = before_services[:tp_start + 1]
                suffix = before_services[tp_end:]
                tpo = []
                i = tp_start + 1
                while i < tp_end:
                    keyline = before_services[i]
                    hp = keyline.strip().split(":")
                    try:
                        tpk = (int(hp[0], 16), int(hp[1], 16), int(hp[2], 16)) if len(hp) >= 3 else None
                    except Exception:
                        tpk = None
                    rec = [keyline]
                    i += 1
                    while i < tp_end:
                        rec.append(before_services[i])
                        done = before_services[i].strip() == "/"
                        i += 1
                        if done:
                            break
                    if tpk in removed_tpkeys and tpk not in remaining_tpkeys:
                        removed_tps += 1
                    else:
                        tpo.extend(rec)
                before_services = prefix + tpo + suffix
            except Exception as e:
                log("profile replace transponder prune skipped: %s" % e)

            out = before_services + new_services + after_services

        try:
            tmp = path + ".abertis-profile-replace.tmp"
            with open(tmp, "w") as f:
                f.write("\n".join(out) + "\n")
            os.rename(tmp, path)
            self.profile_lamedb_cleaned = True
            try:
                eDVBDB.getInstance().reloadServicelist()
            except Exception as e:
                log("profile replace reloadServicelist failed: %s" % e)
            log("profile replace removed %s services=%d orphan_transponders=%d from %s" %
                (self.selected_profile_name, removed_services, removed_tps, path))
            return True
        except Exception as e:
            log("profile replace write failed %s: %s" % (path, e))
            return False

    def _restore_profile_lamedb_backup(self):
        if not self.profile_lamedb_cleaned or not self.profile_lamedb_backup:
            return
        try:
            path = _lamedb_path()
            shutil.copy2(self.profile_lamedb_backup, path)
            eDVBDB.getInstance().reloadServicelist()
            log("profile replace rollback restored %s" % path)
        except Exception as e:
            log("profile replace rollback failed: %s" % e)
        self.profile_lamedb_cleaned = False

    def _make_queue(self, mode):
        q = []
        if mode == "test":
            p = PROFILES[0]
            for carrier in p[4][:2]:
                sid, pid, outer_pmt_pid = carrier_values(carrier)
                q.append((p, sid, pid))
            return q
        if mode.startswith("profile:"):
            name = mode.split(":", 1)[1]
            for p in PROFILES:
                if p[0] == name:
                    for carrier in p[4]:
                        sid, pid, outer_pmt_pid = carrier_values(carrier)
                        q.append((p, sid, pid))
                    return q
            return q
        for p in PROFILES:
            for carrier in p[4]:
                sid, pid, outer_pmt_pid = carrier_values(carrier)
                q.append((p, sid, pid))
        return q

    def _start_once(self):
        if self._started:
            return
        self._started = True
        try:
            open(LOGFILE, "w").close()
        except Exception:
            pass
        if self.feid < 0:
            self.session.open(MessageBox, "No DVB-S/S2 tuner is configured.", MessageBox.TYPE_ERROR)
            self.close()
            return
        if (not os.path.exists(PARAM_PID) or not os.path.exists(PARAM_SID) or
                not os.path.exists(PARAM_FORCE_ENABLE) or not os.path.exists(PARAM_RUNTIME_MODE) or
                not os.path.exists(PARAM_INNER_SID) or
                not os.path.exists(PARAM_HOLD_ENABLE) or not os.path.exists(PARAM_HOLD_PID)):
            self.session.open(MessageBox,
                "V13.17 generic Abertis runtime interface is not available.\nInstall the matching aml_hardware_dmx first.",
                MessageBox.TYPE_ERROR)
            self.close()
            return
        # Single-frequency replace: capture the previous result set for this
        # profile and remove only those inner services from lamedb before the
        # fresh scan.  Other profiles are not touched.
        self._capture_previous_profile_refs()
        if self.previous_profile_service_keys:
            if not self._remove_previous_profile_from_lamedb():
                self._fatal("Cannot prepare the selected frequency for a clean re-scan.")
                return

        # v6.1: the scanner must own nav play/stop before the first selector is
        # armed.  Otherwise hidden_ca sees the OUTER data service as an unmapped
        # foreground service and clears runtime_mode/PID/SID immediately.
        if hidden_ca is not None:
            try:
                hidden_ca.install(self.session, find_source_ref, PROFILES)
                if not hidden_ca.scanner_enter(self.session):
                    log("WARNING hidden_ca scanner ownership was not acquired")
            except Exception as e:
                self._fatal("Cannot enter hidden-CA scanner ownership: %s" % e)
                return
        self._next()

    def _set_timer(self, ms, action):
        self.pending_action = action
        try:
            self.timer.start(int(ms), True)
        except TypeError:
            self.timer.start(int(ms), 1)

    def _timer_fired(self):
        a = self.pending_action
        self.pending_action = None
        if a and not self.cancelled:
            a()

    def _next(self):
        if self.cancelled:
            return
        if self.index >= len(self.queue):
            self._finish_all()
            return
        profile, sid, pid = self.queue[self.index]
        self.scan_pid = pid
        self.scan_retry = 0
        self._prepare_current(profile, sid, pid)

    def _disarm_hold(self):
        try:
            write_param(PARAM_HOLD_ENABLE, 0)
            write_param(PARAM_HOLD_PID, -1)
        except Exception as e:
            log("helper hold disarm failed: %s" % e)

    def _arm_scan_selector(self, sid, pid):
        # Publish the whole runtime tuple while disabled, then enable it.
        # mode=1 means scanner pipe: outer service remains visible until CW,
        # then only confirmed inner SECTION data is supplied to eDVBScan.
        write_param(PARAM_FORCE_ENABLE, 0)
        write_param(PARAM_RUNTIME_MODE, 1)
        write_param(PARAM_PID, int(pid))
        write_param(PARAM_SID, int(sid))
        write_param(PARAM_INNER_SID, -1)
        write_param(PARAM_FORCE_ENABLE, 1)

    def _prepare_current(self, profile, sid, pid):
        self._disarm_hold()
        try:
            self._arm_scan_selector(sid, pid)
        except Exception as e:
            self._fatal("Cannot set driver selector: %s" % e)
            return
        self.scan_retry = 0
        self.scan_had_source = False
        self.bootstrap_scan = False
        self.post_verify_info = None
        self["status"].setText("%d/%d  %s   hidden PID %d   source SID %d" %
                               (self.index + 1, len(self.queue), profile[0], pid, sid))
        source_ref = find_source_ref(sid, profile[1])
        if source_ref:
            profile_changed = (self.last_source_profile != profile[0])
            if profile_changed:
                old_profile = self.last_source_profile
                self.last_source_profile = profile[0]
                # A source service on a new RF profile must not inherit the
                # previous profile's persistent bridge/CA state.  This is the
                # same proven clean transition used by a single-profile scan,
                # now repeated at every RF boundary.
                log("profile clean transition %s->%s sid=%d pid=%d: stop current service; wait 1250ms before source activation" %
                    (old_profile if old_profile is not None else "START", profile[0], sid, pid))
                self["detail"].setText("Preparing %s hidden carriers cleanly..." % profile[0])
                try:
                    self.session.nav.stopService()
                except Exception:
                    pass
                self._set_timer(1250, lambda: self._activate_source(profile, sid, pid, source_ref))
            else:
                self._activate_source(profile, sid, pid, source_ref)
        else:
            self["detail"].setText("Physical transponder is not in lamedb yet; bootstrap scan once...")
            log("carrier %s sid=%d pid=%d physical TP missing; bootstrap scan" % (profile[0], sid, pid))
            self.bootstrap_scan = True
            self.scan_hits_before = read_int(PARAM_HITS, 0)
            self._start_scan(profile, sid, pid)

    def _activate_source(self, profile, sid, pid, source_ref):
        self.scan_had_source = True
        self.bootstrap_scan = False
        self.source_hits_before = read_int(PARAM_HITS, 0)
        self.source_ready_before = read_int(PARAM_FORCE_READY, 0)
        self.source_inner_before = read_int(PARAM_INNER, 0)
        # One bounded activation attempt per carrier.  v6.2.2 removes the
        # global second pass; RF-boundary cleanup addresses the real cross-RF
        # failure instead of repeating the same stale-state attempt.
        self.source_wait_deadline = time.time() + 12.0
        self["detail"].setText("Activating outer SID %d and waiting for hidden PID %d CW..." % (sid, pid))
        log("carrier %s sid=%d pid=%d activate source=%s hits=%d ready=%d inner=%d pass=%d" %
            (profile[0], sid, pid, source_ref, self.source_hits_before,
             self.source_ready_before, self.source_inner_before, 1))
        try:
            # stopService/playService are wrapped by hidden_ca.py.  Re-publish
            # scanner ownership here so the 1250 ms first-carrier stop cannot
            # leave the kernel selector disarmed.
            self._arm_scan_selector(sid, pid)
            self.session.nav.playService(eServiceReference(source_ref))
        except Exception as e:
            log("source zap failed: %s" % e)
        self._set_timer(250, lambda: self._wait_source_ready(profile, sid, pid))

    def _wait_source_ready(self, profile, sid, pid):
        if self.cancelled:
            return
        hits = read_int(PARAM_HITS, 0)
        ready = read_int(PARAM_FORCE_READY, 0)
        last_pid = read_int(PARAM_LAST_PID, -1)
        inner = read_int(PARAM_INNER, 0)
        cw_ready = ready > self.source_ready_before
        decoded_new = hits > self.source_hits_before and last_pid == pid
        # A stale persistent bridge can move the inner counter by a few packets
        # without carrying the selected hidden transport.  Never accept that as
        # source-ready.  The scan handoff requires a fresh decoder hit (or an
        # explicit CW-ready transition) for this selected PID.
        decoded = decoded_new
        if cw_ready or decoded:
            log("source ready %s sid=%d pid=%d cw_ready=%s decoded=%s fresh_hit=%s hits=%d->%d ready=%d->%d inner=%d->%d last_pid=%d" %
                (profile[0], sid, pid, cw_ready, decoded, decoded_new,
                 self.source_hits_before, hits, self.source_ready_before, ready,
                 self.source_inner_before, inner, last_pid))
            try:
                # Arm before stopService(), because CA_SET_PID(remove)/CA_RESET
                # is the event that transfers the already-programmed DSC
                # channel to the helper-only short hold.
                write_param(PARAM_HOLD_PID, pid)
                write_param(PARAM_HOLD_ENABLE, 1)
            except Exception as e:
                self._fatal("Cannot arm helper CW handoff: %s" % e)
                return
            self.scan_hits_before = hits
            self.scan_retry = 0
            self["detail"].setText("CW ready; handing PID %d into inner scan..." % pid)
            try:
                self.session.nav.stopService()
            except Exception:
                pass
            self._set_timer(180, lambda: self._start_scan(profile, sid, pid))
            return
        if time.time() < self.source_wait_deadline:
            self._set_timer(250, lambda: self._wait_source_ready(profile, sid, pid))
            return
        log("source ready timeout %s sid=%d pid=%d hits=%d->%d ready=%d->%d inner=%d->%d last_pid=%d pass=%d" %
            (profile[0], sid, pid, self.source_hits_before, hits,
             self.source_ready_before, ready, self.source_inner_before, inner,
             last_pid, 1))
        self._disarm_hold()
        try:
            self.session.nav.stopService()
        except Exception:
            pass
        self._record(False, profile, sid, pid, "outer SID did not activate selected hidden PID")
        self.index += 1
        self._set_timer(500, self._next)

    def _start_scan(self, profile, sid, pid):
        if self.cancelled:
            return
        self._cleanup_scan()
        self.scan_found_services = []
        self.scan = eComponentScan()
        self.scan.statusChanged.get().append(self._scan_status)
        try:
            self.scan.newService.get().append(self._new_service)
        except Exception:
            pass
        self.scan.addInitial(build_satparm(profile))
        self["progress"].setValue(0)
        log("scan start feid=%d %s sid=%d pid=%d attempt=%d" %
            (self.feid, profile[0], sid, pid, self.scan_retry + 1))
        err = self.scan.start(self.feid, 0, 0)
        if err:
            log("scan start error=%s" % err)
            self._cleanup_scan()
            # A current service can own the only frontend.  Retry once after
            # stopping it; if the driver already saw the CW, its live bridge
            # can still be used, otherwise this carrier is reported failed.
            if self.scan_retry == 0:
                self.scan_retry = 1
                try:
                    self.session.nav.stopService()
                except Exception:
                    pass
                self._set_timer(250, lambda: self._start_scan(profile, sid, pid))
            else:
                self._record(False, profile, sid, pid, "scan-start-error")
                self.index += 1
                self._set_timer(200, self._next)

    def _new_service(self):
        if self.scan is None:
            return
        try:
            name = self.scan.getLastServiceName()
        except Exception:
            name = ""
        try:
            ref = self.scan.getLastServiceRef()
            refstr = _ref_string(ref)
        except Exception as e:
            log("new service ref read failed: %s" % e)
            return
        if not refstr:
            return
        name = _safe_service_name(name)
        item = (name, refstr)
        if item not in self.scan_found_services:
            self.scan_found_services.append(item)
            try:
                hidden_pid = int(self.queue[self.index][2])
            except Exception:
                hidden_pid = -1
            # Do not expose/save this reference in the final Abertis bouquet yet.
            # It becomes trusted only after _verify_scan_result() proves a fresh
            # hidden bridge hit for the selected PID.
            log("new service name=%r ref=%s hidden_pid=%d" % (name, refstr, hidden_pid))

    def _scan_status(self):
        if self.scan is None:
            return
        try:
            self["progress"].setValue(min(100, int(self.scan.getProgress())))
        except Exception:
            pass
        try:
            if not self.scan.isDone():
                return
        except Exception:
            return
        profile, sid, pid = self.queue[self.index]
        try:
            err = self.scan.getError()
        except Exception:
            err = -1
        try:
            num = self.scan.getNumServices()
        except Exception:
            num = -1
        self._cleanup_scan()
        self.post_verify_deadline = time.time() + 1.5
        self.post_verify_info = (profile, sid, pid, err, num, bool(self.bootstrap_scan), list(self.scan_found_services))
        self._verify_scan_result()

    def _verify_scan_result(self):
        if self.cancelled or not self.post_verify_info:
            return
        profile, sid, pid, err, num, was_bootstrap, found_services = self.post_verify_info
        hits_after = read_int(PARAM_HITS, 0)
        last_pid = read_int(PARAM_LAST_PID, -1)
        hidden_hit = hits_after > self.scan_hits_before and last_pid == pid
        if hidden_hit:
            log("scan done %s sid=%d pid=%d error=%s services=%s hidden_hit=True hits=%d->%d last_pid=%d" %
                (profile[0], sid, pid, err, num, self.scan_hits_before, hits_after, last_pid))
            self.post_verify_info = None
            self._disarm_hold()
            # Only confirmed hidden-transport services are allowed into the
            # final bouquet/CAID update set.
            configured = find_carrier(profile, sid, pid)
            if configured is None:
                self._fatal("Carrier tuple is missing from abertis_config.py: %s SID %d PID %d" %
                            (profile[0], sid, pid))
                return
            _source_sid, _hidden_pid, outer_pmt_pid = configured
            for found_name, found_ref in found_services:
                existing = None
                for old_name, old_ref, old_pid in self.all_found_services:
                    if old_ref == found_ref:
                        existing = (old_name, old_ref, old_pid)
                        break
                if existing is None:
                    self.all_found_services.append((found_name, found_ref, int(pid)))
                elif existing[2] != int(pid):
                    log("WARNING service-ref collision ref=%s old_pid=%d new_pid=%d" %
                        (found_ref, existing[2], int(pid)))
                refkey = str(found_ref or "").strip()
                parts = refkey.split(":")
                if len(parts) >= 10 and parts[0] == "1":
                    refkey = ":".join(parts[:10]) + ":"
                meta = (profile[0], int(sid), int(pid), int(outer_pmt_pid))
                previous = self.service_carrier_meta.get(refkey)
                if previous is not None and previous != meta:
                    self.service_carrier_ambiguous.add(refkey)
                    log("WARNING complete carrier mapping collision ref=%s old=%r new=%r" %
                        (refkey, previous, meta))
                else:
                    self.service_carrier_meta[refkey] = meta
            self._commit_found_services(profile, pid, found_services)
            self._record(True, profile, sid, pid, "%s services" % num)
            self.index += 1
            self._set_timer(250, self._next)
            return

        if time.time() < self.post_verify_deadline:
            self._set_timer(250, self._verify_scan_result)
            return

        log("scan done %s sid=%d pid=%d error=%s services=%s hidden_hit=False hits=%d->%d last_pid=%d bootstrap=%s" %
            (profile[0], sid, pid, err, num, self.scan_hits_before, hits_after, last_pid, was_bootstrap))
        self.post_verify_info = None
        self._disarm_hold()

        # A bootstrap pass only exists to put the physical RF transponder in
        # lamedb.  Once it is known, synthesize/locate the data-service ref and
        # activate the requested outer SID before doing the real inner scan.
        if was_bootstrap:
            source_ref = find_source_ref(sid, profile[1])
            if source_ref:
                self._activate_source(profile, sid, pid, source_ref)
                return

        self._record(False, profile, sid, pid, "no hidden bridge confirmation")
        self.index += 1
        self._set_timer(250, self._next)

    def _backup_lamedb_once(self, path):
        if self.lamedb_backup:
            return True
        try:
            backup = path + ".abertis-v13157-before-commit"
            shutil.copy2(path, backup)
            self.lamedb_backup = backup
            log("lamedb backup=%s" % backup)
            return True
        except Exception as e:
            log("lamedb backup failed path=%s error=%s" % (path, e))
            return False

    def _commit_found_services(self, profile, hidden_pid, found_services):
        """Fallback for Enigma2 scans that count the inner services but reject
        the reconstructed transport at channelDone().  Preserve the service
        identities emitted by eComponentScan, add only missing records, and
        attach the known Abertis data PID/CAID so a later zap can prime the
        same hidden PID through the normal Enigma2/OSCam path.
        """
        if not found_services:
            log("commit %s pid=%d: scan emitted no newService refs; nothing to persist" %
                (profile[0], hidden_pid))
            return

        path = _lamedb_path()
        try:
            with open(path, "r") as f:
                lines = [x.rstrip("\n") for x in f]
        except Exception as e:
            log("commit %s pid=%d: cannot read %s: %s" % (profile[0], hidden_pid, path, e))
            return
        if not lines:
            log("commit %s pid=%d: empty lamedb" % (profile[0], hidden_pid))
            return

        parsed = []
        for name, refstr in found_services:
            ident = _service_ref_parts(refstr)
            if not ident:
                log("commit skip unparsable ref=%s" % refstr)
                continue
            # Reject an all-unknown identity rather than risk corrupting the DB.
            if ident["tsid"] in (0xffff, 0xffffffff) or ident["onid"] in (0xffff, 0xffffffff):
                log("commit skip unresolved transport ref=%s" % refstr)
                continue
            parsed.append((name, refstr, ident))
        if not parsed:
            log("commit %s pid=%d: no safe DVB service refs" % (profile[0], hidden_pid))
            return

        header = lines[0].strip()
        is_v5 = "/5/" in header
        freq, sr = int(profile[1]), int(profile[2])
        rf = _find_rf_params_v5(lines, freq, sr) if is_v5 else _find_rf_params_v4(lines, freq, sr)
        if not rf:
            log("commit %s pid=%d: physical RF parameters not found in %s" % (profile[0], hidden_pid, path))
            return

        added_services = 0
        added_tps = 0
        # Work on a copy and perform one atomic replacement.
        out = list(lines)

        if is_v5:
            existing_tps = set()
            existing_svcs = set()
            for line in out:
                if line.startswith("t:"):
                    existing_tps.add(line.split(",", 1)[0].lower())
                elif line.startswith("s:"):
                    existing_svcs.add(line.split(",", 1)[0].lower())

            tp_lines = []
            svc_lines = []
            for name, refstr, ident in parsed:
                tpkey = "t:%08x:%04x:%04x" % (ident["ns"], ident["tsid"], ident["onid"])
                if tpkey.lower() not in existing_tps:
                    tp_lines.append(tpkey + "," + rf)
                    existing_tps.add(tpkey.lower())
                    added_tps += 1
                svckey = "s:%04x:%08x:%04x:%04x:%x:0:0" % (
                    ident["sid"], ident["ns"], ident["tsid"], ident["onid"], ident["stype"])
                # A lamedb may already contain the service with another type;
                # match the DVB identity first four fields as well.
                identity_prefix = "s:%04x:%08x:%04x:%04x:" % (
                    ident["sid"], ident["ns"], ident["tsid"], ident["onid"])
                if not any(x.startswith(identity_prefix.lower()) for x in existing_svcs):
                    qname = _safe_service_name(name).replace('"', "'")
                    svc_lines.append('%s,"%s",p:Abertis' % (svckey, qname))
                    existing_svcs.add(svckey.lower())
                    added_services += 1
                    self.committed_services.append((name, refstr, hidden_pid))

            if tp_lines:
                first_service = len(out)
                for i, line in enumerate(out):
                    if line.startswith("s:"):
                        first_service = i
                        break
                out[first_service:first_service] = tp_lines
            if svc_lines:
                out.extend(svc_lines)
        else:
            # v4 has explicit transponders/end and services/end sections.
            try:
                tp_start = out.index("transponders")
                tp_end = out.index("end", tp_start + 1)
                svc_start = out.index("services", tp_end + 1)
                svc_end = out.index("end", svc_start + 1)
            except Exception as e:
                log("commit %s pid=%d: malformed lamedb4: %s" % (profile[0], hidden_pid, e))
                return

            existing_tp_keys = set()
            i = tp_start + 1
            while i < tp_end:
                q = out[i].strip()
                if re.match(r"^[0-9a-fA-F]+:[0-9a-fA-F]+:[0-9a-fA-F]+$", q):
                    existing_tp_keys.add(q.lower())
                i += 1

            existing_service_identity = set()
            i = svc_start + 1
            while i < svc_end:
                q = out[i].strip()
                parts = q.split(":")
                if len(parts) >= 4 and all(re.match(r"^[0-9a-fA-F]+$", x or "x") for x in parts[:4]):
                    existing_service_identity.add(":".join(parts[:4]).lower())
                i += 1

            tp_insert = []
            svc_insert = []
            for name, refstr, ident in parsed:
                tpkey = "%08x:%04x:%04x" % (ident["ns"], ident["tsid"], ident["onid"])
                if tpkey.lower() not in existing_tp_keys:
                    tp_insert += [tpkey, "\t" + rf, "/"]
                    existing_tp_keys.add(tpkey.lower())
                    added_tps += 1
                skey = "%04x:%08x:%04x:%04x" % (
                    ident["sid"], ident["ns"], ident["tsid"], ident["onid"])
                if skey.lower() not in existing_service_identity:
                    svc_insert += [
                        "%s:%x:0:0" % (skey, ident["stype"]),
                        _safe_service_name(name),
                        "p:Abertis",
                    ]
                    existing_service_identity.add(skey.lower())
                    added_services += 1
                    self.committed_services.append((name, refstr, hidden_pid))

            if tp_insert:
                out[tp_end:tp_end] = tp_insert
                # service indexes moved by tp insertion
                shift = len(tp_insert)
                svc_start += shift
                svc_end += shift
            if svc_insert:
                out[svc_end:svc_end] = svc_insert

        if not added_services and not added_tps:
            log("commit %s pid=%d: all %d emitted services already present in lamedb" %
                (profile[0], hidden_pid, len(parsed)))
            return
        if not self._backup_lamedb_once(path):
            return
        tmp = path + ".abertis-v13157.tmp"
        try:
            with open(tmp, "w") as f:
                f.write("\n".join(out) + "\n")
            os.rename(tmp, path)
            # Do not reloadServicelist here.  Reloading the live Enigma2 DB
            # between Abertis carriers can invalidate service objects owned by
            # the running scan screen.  Commit to disk now and reload once at
            # _finish_all() after every carrier is complete.
            log("commit %s pid=%d: added_services=%d added_transponders=%d captured=%d" %
                (profile[0], hidden_pid, added_services, added_tps, len(parsed)))
        except Exception as e:
            log("commit %s pid=%d write failed: %s" % (profile[0], hidden_pid, e))
            try:
                if os.path.exists(tmp):
                    os.unlink(tmp)
            except Exception:
                pass

    def _ensure_bouquet_registered(self, master_path, bouquet_name, radio=False):
        try:
            line = '#SERVICE 1:7:%d:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % (
                2 if radio else 1, bouquet_name)
            old = []
            if os.path.exists(master_path):
                with open(master_path, "r") as f:
                    old = [x.rstrip("\n") for x in f]
            if line not in old:
                old.append(line)
                tmp = master_path + ".abertis-v13157.tmp"
                with open(tmp, "w") as f:
                    f.write("\n".join(old) + "\n")
                os.rename(tmp, master_path)
        except Exception as e:
            log("bouquet register failed %s: %s" % (master_path, e))

    def _write_service_map(self):
        """Replace only the selected frequency inside the cumulative map.

        Rows belonging to other frequencies stay untouched.  All previous rows
        for the selected profile are removed first, then the services confirmed
        by this run are written back.  This also removes channels which no
        longer exist after a re-scan.
        """
        rows = self._load_accumulated_map_rows()
        removed = 0
        if self.selected_profile_name:
            for refstr in list(rows):
                row = rows.get(refstr)
                if row and len(row) >= 2 and str(row[1]) == str(self.selected_profile_name):
                    self.previous_profile_refs.add(self._normalize_ref(refstr))
                    rows.pop(refstr, None)
                    removed += 1
        log("mapping profile replace %s removed_old=%d preserved_other=%d" %
            (self.selected_profile_name, removed, len(rows)))

        new_rows = {}
        ambiguous = set()
        for name, refstr, hidden_pid in self.all_found_services:
            refstr = self._normalize_ref(refstr)
            if not refstr:
                continue
            if refstr in self.service_carrier_ambiguous:
                log("mapping skip ambiguous complete carrier ref=%s" % refstr)
                continue
            meta = self.service_carrier_meta.get(refstr)
            if meta is None:
                log("mapping skip ref=%s pid=%d: complete carrier metadata missing" %
                    (refstr, int(hidden_pid)))
                continue
            profile_name, source_sid, pid, outer_pmt_pid = meta
            row = (int(pid), str(profile_name), int(source_sid), int(outer_pmt_pid),
                   _safe_service_name(name))
            if refstr in new_rows and new_rows[refstr][:4] != row[:4]:
                ambiguous.add(refstr)
            else:
                new_rows[refstr] = row
        for refstr in ambiguous:
            new_rows.pop(refstr, None)
            log("mapping skip ambiguous ref=%s" % refstr)

        # Fresh scan result replaces the selected profile.  Unrelated rows are
        # preserved exactly as they were.
        rows.update(new_rows)
        tmp = MAPFILE + ".tmp"
        try:
            with open(tmp, "w") as f:
                f.write("# Hispasat Abertis native map v2\n")
                f.write("# ref\thidden_pid\tprofile\tsource_sid\touter_pmt_pid\tname\n")
                for refstr in sorted(rows):
                    pid, profile_name, source_sid, outer_pmt_pid, safe_name = rows[refstr]
                    safe_name = safe_name.replace("\t", " ").replace("\n", " ").replace("\r", " ")
                    f.write("%s\t%d\t%s\t%d\t%d\t%s\n" %
                            (refstr, pid, profile_name, source_sid, outer_pmt_pid, safe_name))
            os.rename(tmp, MAPFILE)
            log("mapping v2 profile replace wrote %s total=%d current_profile=%d removed_old=%d" %
                (MAPFILE, len(rows), len(new_rows), removed))
            return len(rows)
        except Exception as e:
            log("mapping write failed %s: %s" % (MAPFILE, e))
            try:
                if os.path.exists(tmp):
                    os.unlink(tmp)
            except Exception:
                pass
            return 0

    def _write_found_bouquets(self):
        # Even when this re-scan finds zero services we still rewrite the
        # selected profile out of the cumulative bouquet, while preserving all
        # unrelated profile entries.

        # Never create dead bouquet entries.  Only expose refs that are now
        # really present in lamedb (either saved by eDVBScan itself or by the
        # guarded fallback above).
        saved = set()
        path = _lamedb_path()
        try:
            with open(path, "r") as f:
                db_lines = [x.rstrip("\n") for x in f]
            is_v5 = bool(db_lines and "/5/" in db_lines[0])
            if is_v5:
                for line in db_lines:
                    if not line.startswith("s:"):
                        continue
                    head = line.split(",", 1)[0].split(":")
                    if len(head) >= 5:
                        try:
                            saved.add((int(head[1], 16), int(head[2], 16),
                                       int(head[3], 16), int(head[4], 16)))
                        except Exception:
                            pass
            else:
                in_services = False
                for line in db_lines:
                    q = line.strip()
                    if q == "services":
                        in_services = True
                        continue
                    if in_services and q == "end":
                        break
                    if not in_services:
                        continue
                    head = q.split(":")
                    if len(head) >= 4:
                        try:
                            saved.add((int(head[0], 16), int(head[1], 16),
                                       int(head[2], 16), int(head[3], 16)))
                        except Exception:
                            pass
        except Exception as e:
            log("bouquet: cannot verify lamedb services: %s" % e)

        tv = []
        radio = []
        seen = set()
        for name, refstr, hidden_pid in self.all_found_services:
            if refstr in seen:
                continue
            seen.add(refstr)
            ident = _service_ref_parts(refstr)
            if not ident:
                continue
            key = (ident["sid"], ident["ns"], ident["tsid"], ident["onid"])
            if saved and key not in saved:
                # The scan callback already proved this carrier with a fresh
                # hidden hit.  Some DreamOS lamedb writers normalize the
                # service/transponder identity differently, so do not throw
                # away a confirmed service merely because this secondary
                # verifier disagrees.
                log("bouquet verifier mismatch ref=%s pid=%d; keeping confirmed scan ref" %
                    (refstr, hidden_pid))
            row = (name, refstr, hidden_pid)
            if ident["stype"] in (2, 10):
                radio.append(row)
            else:
                tv.append(row)

        def write_one(filename, title, rows, radio_mode=False):
            path = "/etc/enigma2/" + filename

            # Preserve services accumulated by previous single-frequency scans.
            order = []
            merged = {}
            try:
                if os.path.exists(path):
                    with open(path, "r") as f:
                        old_lines = [x.rstrip("\n") for x in f]
                    i = 0
                    while i < len(old_lines):
                        line = old_lines[i]
                        if line.startswith("#SERVICE "):
                            ref = self._normalize_ref(line[len("#SERVICE "):].strip())
                            desc = ""
                            if i + 1 < len(old_lines) and old_lines[i + 1].startswith("#DESCRIPTION "):
                                desc = old_lines[i + 1][len("#DESCRIPTION "):].strip()
                                i += 1
                            # Re-scan replacement: drop every old ref owned
                            # by the selected frequency.  It will be re-added
                            # below only if the fresh scan found it again.
                            if ref in self.previous_profile_refs:
                                continue
                            if ref and ref not in merged:
                                order.append(ref)
                                merged[ref] = desc
                        i += 1
            except Exception as e:
                log("bouquet cumulative load failed %s: %s" % (path, e))

            for name, refstr, hidden_pid in rows:
                refstr = self._normalize_ref(refstr)
                if not refstr:
                    continue
                if refstr not in merged:
                    order.append(refstr)
                merged[refstr] = "%s [Abertis PID %d]" % (_safe_service_name(name), hidden_pid)

            lines = ["#NAME " + title]
            for refstr in order:
                lines.append("#SERVICE " + refstr)
                desc = merged.get(refstr, "")
                if desc:
                    lines.append("#DESCRIPTION " + desc)
            try:
                tmp = path + ".tmp"
                with open(tmp, "w") as f:
                    f.write("\n".join(lines) + "\n")
                os.rename(tmp, path)
                self._ensure_bouquet_registered(
                    "/etc/enigma2/bouquets.radio" if radio_mode else "/etc/enigma2/bouquets.tv",
                    filename, radio=radio_mode)
                log("bouquet profile replace wrote %s total=%d current_run=%d removed_old_refs=%d" %
                    (path, len(order), len(rows), len(self.previous_profile_refs)))
                return len(order)
            except Exception as e:
                log("bouquet write failed %s: %s" % (path, e))
                return 0

        tvn = write_one("userbouquet.hispasat_abertis_native.tv",
                        "Hispasat 30W - Abertis Native", tv, False)
        rdn = write_one("userbouquet.hispasat_abertis_native.radio",
                        "Hispasat 30W - Abertis Native Radio", radio, True)
        try:
            eDVBDB.getInstance().reloadBouquets()
        except Exception as e:
            log("reloadBouquets failed: %s" % e)
        log("bouquet complete tv=%d radio=%d captured=%d" % (tvn, rdn, len(self.all_found_services)))

    def _cleanup_scan(self):
        if self.scan is None:
            return
        try:
            self.scan.statusChanged.get().remove(self._scan_status)
        except Exception:
            pass
        try:
            self.scan.newService.get().remove(self._new_service)
        except Exception:
            pass
        self.scan = None

    def _record(self, ok, profile, sid, pid, note):
        self.results.append((ok, profile[0], sid, pid, note))
        self["detail"].setText(("OK" if ok else "MISS") + "  %s PID %d / SID %d  %s" %
                               (profile[0], pid, sid, note))

    def _restore(self):
        self._cleanup_scan()
        try:
            self.timer.stop()
        except Exception:
            pass
        try:
            write_param(PARAM_HOLD_ENABLE, 0)
            write_param(PARAM_HOLD_PID, -1)
            write_param(PARAM_FORCE_ENABLE, 0)
            write_param(PARAM_RUNTIME_MODE, 0)
            write_param(PARAM_INNER_SID, -1)
            write_param(PARAM_PID, -1)
            write_param(PARAM_SID, -1)
        except Exception as e:
            log("restore params failed: %s" % e)
        # End scanner ownership BEFORE restoring the saved foreground service,
        # so a mapped Abertis service gets the normal v6.x CA injection again.
        if hidden_ca is not None:
            try:
                hidden_ca.scanner_leave(self.session)
            except Exception as e:
                log("hidden_ca scanner leave failed: %s" % e)
        try:
            if self.saved_service:
                self.session.nav.playService(self.saved_service)
        except Exception:
            pass

    def _finish_all(self):
        # v4.7: normal inner services stay clean/FTA in lamedb.  Hidden CA is
        # supplied separately to OSCam by hidden_ca.py; never add C:2600 or
        # any lowercase c:XX cache field to the inner service.
        try:
            eDVBDB.getInstance().reloadServicelist()
            log("final service-list reload complete")
        except Exception as e:
            log("final reloadServicelist failed: %s" % e)
        mapped = self._write_service_map()
        self._write_found_bouquets()
        log("v6.2.2 single-profile replace final mapping services=%d" % mapped)
        self.finished_successfully = True
        self._restore()
        ok = sum(1 for x in self.results if x[0])
        fail = len(self.results) - ok
        log("finished ok=%d miss=%d" % (ok, fail))
        text = "Hispasat Abertis scan finished.\n\nConfirmed hidden muxes: %d\nMissed: %d\n\nLog: %s" % (ok, fail, LOGFILE)
        self.session.openWithCallback(lambda *a: self.close(), MessageBox, text, MessageBox.TYPE_INFO)

    def _fatal(self, text):
        log("FATAL " + text)
        if not self.finished_successfully:
            self._restore_profile_lamedb_backup()
        self._restore()
        self.session.openWithCallback(lambda *a: self.close(), MessageBox, text, MessageBox.TYPE_ERROR)

    def cancel(self):
        self.cancelled = True
        if not self.finished_successfully:
            self._restore_profile_lamedb_backup()
        self._restore()
        self.close()


def choice_callback(session, choice):
    if not choice:
        return
    mode = choice[1]
    session.open(AbertisScanRunner, mode)


def main(session, **kwargs):
    # Single-frequency workflow only.  TEST and ALL-profiles modes are hidden
    # from the UI so every run has exactly one RF profile.
    choices = []
    for index, p in enumerate(PROFILES, 1):
        choices.append(("%d. %s - %d hidden carriers" % (index, p[0], len(p[4])),
                        "profile:" + p[0]))
    # Do not let ChoiceBox assign its automatic 1..9,0,red... shortcut
    # glyphs.  The visible list is numbered explicitly so entries 10 and 11
    # display as 10 and 11 rather than 0 and a red-key marker.
    session.openWithCallback(lambda c: choice_callback(session, c), ChoiceBox,
                             title="Hispasat Abertis - choose one frequency",
                             list=choices, keys=[""] * len(choices))


def hidden_ca_status(session, **kwargs):
    if hidden_ca is None:
        session.open(MessageBox, "Hidden CA module could not be imported.", MessageBox.TYPE_ERROR)
        return
    try:
        hidden_ca.install(session, find_source_ref, PROFILES)
        text = hidden_ca.inject_current(session)
    except Exception as e:
        text = "Hidden CA error: %s" % e
    session.open(MessageBox, text, MessageBox.TYPE_INFO)


def sessionstart(reason, **kwargs):
    # Install one lightweight playService/stopService wrapper only.  There is
    # deliberately no eTimer, nav-event callback, poller or automatic source zap.
    if reason != 0 or hidden_ca is None:
        return
    session = kwargs.get("session")
    if session is None:
        return
    try:
        hidden_ca.install(session, find_source_ref, PROFILES)
    except Exception as e:
        log("hidden CA sessionstart install failed: %s" % e)


def Plugins(**kwargs):
    return [
        PluginDescriptor(name="Hispasat Abertis Scan",
                         description="Scan configured Abertis hidden carriers one by one",
                         where=PluginDescriptor.WHERE_PLUGINMENU,
                         fnc=main),
        PluginDescriptor(name="Hispasat Abertis Hidden CA",
                         description="Inject the mapped outer Abertis CA_PMT to OSCam for the current service",
                         where=PluginDescriptor.WHERE_PLUGINMENU,
                         fnc=hidden_ca_status),
        PluginDescriptor(where=PluginDescriptor.WHERE_SESSIONSTART,
                         fnc=sessionstart),
    ]
