#!/usr/bin/env python
# Remove ONLY the experimental uppercase C:2600 marker from services contained
# in the Abertis bouquets.  No lowercase c:XX cache fields are touched.
from __future__ import print_function
import os, re, shutil

BOUQUETS = (
    "/etc/enigma2/userbouquet.hispasat_abertis_native.tv",
    "/etc/enigma2/userbouquet.hispasat_abertis_native.radio",
)


def canon(s):
    p = s.strip().split(":")
    return ":".join(p[:10]) + ":" if len(p) >= 10 else s.strip()


def ident(s):
    p = canon(s).split(":")
    try:
        return (int(p[3],16), int(p[6],16), int(p[4],16), int(p[5],16))
    except Exception:
        return None

wanted=set()
for bp in BOUQUETS:
    if not os.path.exists(bp):
        continue
    for line in open(bp, "r"):
        if line.startswith("#SERVICE "):
            x=ident(line[len("#SERVICE "):])
            if x:
                wanted.add(x)

path = "/etc/enigma2/lamedb" if os.path.exists("/etc/enigma2/lamedb") else "/etc/enigma2/lamedb5"
if not os.path.exists(path):
    raise SystemExit("No lamedb/lamedb5 found")
lines=[x.rstrip("\n") for x in open(path,"r")]
out=list(lines); changed=0
if lines and "/5/" in lines[0]:
    for i,line in enumerate(out):
        if not line.startswith("s:"):
            continue
        h=line.split(",",1)[0].split(":")
        try:
            key=(int(h[1],16),int(h[2],16),int(h[3],16),int(h[4],16))
        except Exception:
            continue
        if key not in wanted:
            continue
        n=re.sub(r",C:2600(?=,|$)", "", line, flags=re.I)
        if n != line:
            out[i]=n; changed += 1
else:
    try:
        a=out.index("services"); z=out.index("end",a+1)
    except Exception:
        raise SystemExit("Malformed lamedb4")
    i=a+1
    while i+2<z:
        h=out[i].split(":")
        try:
            key=(int(h[0],16),int(h[1],16),int(h[2],16),int(h[3],16))
        except Exception:
            key=None
        if key in wanted:
            old=out[i+2]
            parts=[x for x in old.split(",") if x.upper() != "C:2600"]
            new=",".join(parts)
            if new != old:
                out[i+2]=new; changed += 1
        i += 3
if changed:
    backup=path+".before-abertis-v43-hidden-ca"
    if not os.path.exists(backup):
        shutil.copy2(path,backup)
    tmp=path+".abertis-v43.tmp"
    open(tmp,"w").write("\n".join(out)+"\n")
    os.rename(tmp,path)
print("Removed C:2600 from %d Abertis inner service(s). Lowercase c:XX fields unchanged." % changed)
