# -*- coding: utf-8 -*-
# Hispasat Abertis hidden CA + generic child-mux selector, v6.2.1 scanner-safe bootstrap
# GPL-2.0-or-later
from __future__ import print_function

import os
import re
import socket
import sys
import time

from .abertis_config import (
    CAID, FAKE_ECM_PID, ADAPTER, DEMUX, CA_DEVICE, CHILD_MUX_PRIME_DELAY,
    carrier_values, find_profile,
)

SOCKET_PATH = "/tmp/camd.socket"
LOGFILE = "/tmp/hispasat_abertis_hidden_ca.log"
MAPFILE = "/etc/enigma2/hispasat_abertis_native.map"
BOUQUETS = (
    "/etc/enigma2/userbouquet.hispasat_abertis_native.tv",
    "/etc/enigma2/userbouquet.hispasat_abertis_native.radio",
)
PARAM_BASE = "/sys/module/aml_hardware_dmx/parameters"
PARAM_FORCE_ENABLE = PARAM_BASE + "/e2_abertis_force_enable"
PARAM_FORCE_PID = PARAM_BASE + "/e2_abertis_force_pid"
PARAM_FORCE_SID = PARAM_BASE + "/e2_abertis_force_sid"
PARAM_INNER_SID = PARAM_BASE + "/e2_abertis_child_inner_sid"
PARAM_RUNTIME_MODE = PARAM_BASE + "/e2_abertis_runtime_mode"
PARAM_FORCE_READY = PARAM_BASE + "/e2_abertis_force_ready_hits"
PARAM_HOLD_ENABLE = PARAM_BASE + "/e2_abertis_helper_cw_hold"
PARAM_HOLD_PID = PARAM_BASE + "/e2_abertis_helper_hold_pid"

# v6.2: the synthetic outer CA_PMT is a bootstrap only.  Once V13.17 has
# observed the CW on the selected hidden PID, close camd.socket so OSCam can
# return to the foreground INNER service.  The kernel helper keeps DSC1/CW
# alive across CA_SET_PID(remove).  This is a bounded one-shot wait, not a
# background poller/watcher.
CA_BOOTSTRAP_WAIT = 1.20
CA_BOOTSTRAP_POLL = 0.02

_MANAGER = None


def _log(msg):
    line = time.strftime("%H:%M:%S") + " " + str(msg)
    try:
        print("[HispasatAbertisHiddenCA] " + line)
    except Exception:
        pass
    try:
        with open(LOGFILE, "a") as f:
            f.write(line + "\n")
    except Exception:
        pass



def _read_int(path, default=-1):
    try:
        with open(path, "r") as f:
            return int(f.read().strip(), 0)
    except Exception:
        return default


def _ref_string(ref):
    try:
        return ref.toString()
    except Exception:
        try:
            return str(ref)
        except Exception:
            return ""


def _canonical_ref(ref):
    s = _ref_string(ref).strip()
    parts = s.split(":")
    if len(parts) < 10 or parts[0] != "1":
        return s
    return ":".join(parts[:10]) + ":"


def _parse_ref(ref):
    s = _canonical_ref(ref)
    p = s.split(":")
    try:
        if len(p) < 7 or p[0] != "1":
            return None
        return {
            "stype": int(p[2], 16),
            "sid": int(p[3], 16),
            "tsid": int(p[4], 16),
            "onid": int(p[5], 16),
            "ns": int(p[6], 16),
            "ref": s,
        }
    except Exception:
        return None


def _u16(n):
    n = int(n) & 0xFFFF
    return [n >> 8, n & 0xFF]


def _u32(n):
    n = int(n) & 0xFFFFFFFF
    return [(n >> 24) & 0xFF, (n >> 16) & 0xFF, (n >> 8) & 0xFF, n & 0xFF]


def _wire(data):
    b = bytearray(data)
    if sys.version_info[0] >= 3:
        return bytes(b)
    return str(b)


def build_capmt(source_sid, hidden_pid, namespace, tsid, onid,
                adapter=ADAPTER, demux=DEMUX, ca_device=CA_DEVICE,
                pmt_pid=None):
    """Build one standard Enigma/OSCam CA_PMT object.

    The foreground Enigma2 service is NOT represented here.  The CA object is
    the original outer Abertis service:
      program_number = source SID
      CAID/ECM PID   = configured in abertis_config.py
      stream PID     = hidden Abertis carrier PID

    Program-info also contains OSCam's mandatory adapter/PMT/demux/CA-device
    private descriptors plus the exact Enigma namespace/TSID/ONID tuple.
    """
    source_sid = int(source_sid) & 0xFFFF
    hidden_pid = int(hidden_pid) & 0x1FFF
    if pmt_pid is None:
        raise ValueError("outer PMT PID must be supplied explicitly by abertis_config.py")
    pmt_pid = int(pmt_pid) & 0x1FFF

    desc = bytearray()
    # 0x81: enigma namespace + TSID + ONID (recommended by OSCam)
    desc.extend([0x81, 0x08] + _u32(namespace) + _u16(tsid) + _u16(onid))
    # 0x83/0x84/0x86/0x87: mandatory OSCam CA_PMT private descriptors
    desc.extend([0x83, 0x01, int(adapter) & 0xFF])
    desc.extend([0x84, 0x02] + _u16(pmt_pid))
    desc.extend([0x86, 0x01, int(demux) & 0xFF])
    desc.extend([0x87, 0x01, int(ca_device) & 0xFF])
    # MPEG CA descriptor: both values are userspace configuration.
    caid = int(CAID) & 0xFFFF
    ecm_pid = int(FAKE_ECM_PID) & 0x1FFF
    desc.extend([0x09, 0x04] + _u16(caid) +
                [0xE0 | ((ecm_pid >> 8) & 0x1F), ecm_pid & 0xFF])

    body = bytearray()
    body.append(0x03)  # ca_pmt_list_management = ONLY (one socket/channel)
    body.extend(_u16(source_sid))
    body.append(0x01)  # version 0, current_next_indicator = 1

    # program_info_length includes ca_pmt_cmd_id + all descriptors.
    pil = 1 + len(desc)
    body.extend([0xF0 | ((pil >> 8) & 0x0F), pil & 0xFF])
    body.append(0x01)  # CA_PMT_CMD_OK_DESCRAMBLING
    body.extend(desc)

    # One private-data elementary stream.  This is the PID that OSCam must
    # eventually pass to CA_SET_PID after it resolves the BISS CW.
    body.append(0x06)
    body.extend([0xE0 | ((hidden_pid >> 8) & 0x1F), hidden_pid & 0xFF])
    esil = 1  # ca_pmt_cmd_id only, no ES-local descriptors
    body.extend([0xF0 | ((esil >> 8) & 0x0F), esil & 0xFF])
    body.append(0x01)

    # AOT_CA_PMT + BER length.  OSCam/Enigma old socket mode accepts 0x82 + u16.
    frame = bytearray([0x9F, 0x80, 0x32, 0x82])
    frame.extend(_u16(len(body)))
    frame.extend(body)
    return _wire(frame)


def _hex(data):
    if not isinstance(data, bytearray):
        data = bytearray(data)
    return " ".join("%02x" % x for x in data)


def _load_bouquet_map():
    """Return canonical service ref -> carrier metadata.

    Map v2 is authoritative and contains the complete carrier tuple.  Old v1
    maps/bouquet descriptions remain readable as a compatibility fallback, but
    duplicate hidden PIDs are refused unless v2 disambiguates them.
    """
    result = {}
    ambiguous = set()
    if os.path.exists(MAPFILE):
        try:
            with open(MAPFILE, "r") as f:
                for raw in f:
                    line = raw.strip("\r\n")
                    if not line or line.startswith("#"):
                        continue
                    cols = line.split("\t")
                    if len(cols) < 2:
                        continue
                    ref = _canonical_ref(cols[0])
                    try:
                        pid = int(cols[1], 0)
                    except Exception:
                        continue
                    rec = {"hidden_pid": pid}
                    if len(cols) >= 5:
                        try:
                            rec.update({
                                "profile": cols[2],
                                "source_sid": int(cols[3], 0),
                                "outer_pmt_pid": int(cols[4], 0),
                            })
                        except Exception:
                            continue
                    old = result.get(ref)
                    if old is not None and old != rec:
                        ambiguous.add(ref)
                    else:
                        result[ref] = rec
        except Exception as e:
            _log("cannot read mapping %s: %s" % (MAPFILE, e))

    # Bouquet descriptions are PID-only fallback for an old scan.
    for path in BOUQUETS:
        if not os.path.exists(path):
            continue
        try:
            with open(path, "r") as f:
                lines = [x.rstrip("\n") for x in f]
        except Exception as e:
            _log("cannot read bouquet %s: %s" % (path, e))
            continue
        current = None
        for line in lines:
            if line.startswith("#SERVICE "):
                current = _canonical_ref(line[len("#SERVICE "):].strip())
                continue
            if current and line.startswith("#DESCRIPTION "):
                m = re.search(r"\[Abertis PID\s+([0-9]+)\]", line)
                if m and current not in result:
                    result[current] = {"hidden_pid": int(m.group(1))}
                current = None
    for ref in ambiguous:
        result.pop(ref, None)
        _log("ambiguous mapping skipped ref=%s" % ref)
    return result


class HiddenCAManager(object):
    def __init__(self, session, find_source_ref, profiles):
        self.session = session
        self.find_source_ref = find_source_ref
        self.profiles = profiles
        self.pid_map = {}
        for profile in profiles:
            for carrier in profile[4]:
                sid, pid, pmt_pid = carrier_values(carrier)
                self.pid_map.setdefault(int(pid), []).append(
                    (int(sid), int(pmt_pid), profile))
        self.sock = None
        self.active_key = None
        # CA ownership is per outer hidden carrier, but foreground service
        # selection is per INNER SID.  Keep these states separate so zapping
        # between services carried by the same hidden PID updates the kernel
        # selector without tearing down the working OSCam socket/CW.
        self.active_inner_sid = None
        self.bootstrap_ready_before = 0
        # Scanner owns Navigation while AbertisScanRunner is cycling OUTER
        # source services.  During this window hidden_ca must never interpret
        # those source refs as normal foreground non-Abertis zaps.
        self.scanner_owned = False
        self.original_play = None
        self.original_stop = None
        self.installed = False

    def _write_kernel(self, path, value):
        with open(path, "w") as f:
            f.write(str(value))

    def _disarm_kernel(self, reason="disarm"):
        try:
            if os.path.exists(PARAM_FORCE_ENABLE):
                self._write_kernel(PARAM_FORCE_ENABLE, 0)
                if os.path.exists(PARAM_RUNTIME_MODE):
                    self._write_kernel(PARAM_RUNTIME_MODE, 0)
                if os.path.exists(PARAM_INNER_SID):
                    self._write_kernel(PARAM_INNER_SID, -1)
                if os.path.exists(PARAM_FORCE_PID):
                    self._write_kernel(PARAM_FORCE_PID, -1)
                if os.path.exists(PARAM_FORCE_SID):
                    self._write_kernel(PARAM_FORCE_SID, -1)
                _log("GENERIC_PIPE disarm reason=%s" % reason)
        except Exception as e:
            _log("CHILD_MUX disarm failed reason=%s error=%s" % (reason, e))

    def _arm_kernel(self, info):
        required = (PARAM_FORCE_ENABLE, PARAM_FORCE_PID, PARAM_FORCE_SID,
                    PARAM_INNER_SID, PARAM_RUNTIME_MODE,
                    PARAM_HOLD_ENABLE, PARAM_HOLD_PID)
        missing = [x for x in required if not os.path.exists(x)]
        if missing:
            raise RuntimeError("V13.17 generic-pipe kernel parameters missing: %s" % ", ".join(missing))
        # Publish a complete PID/SID tuple before enabling it.  Arm the
        # V13.17 DSC helper first: when v6.2 closes the synthetic CA socket
        # after CW-ready, CA_SET_PID(remove) marks this exact hidden PID as
        # held instead of freeing its descrambler channel.
        self._write_kernel(PARAM_FORCE_ENABLE, 0)
        self._write_kernel(PARAM_HOLD_PID, int(info["hidden_pid"]))
        self._write_kernel(PARAM_HOLD_ENABLE, 1)
        self._write_kernel(PARAM_RUNTIME_MODE, 2)
        self._write_kernel(PARAM_FORCE_PID, int(info["hidden_pid"]))
        self._write_kernel(PARAM_FORCE_SID, int(info["source_sid"]))
        self._write_kernel(PARAM_INNER_SID, int(info["inner_sid"]))
        self._write_kernel(PARAM_FORCE_ENABLE, 1)
        _log("GENERIC_PIPE arm mode=2 profile=%s source_sid=%d hidden_pid=%d inner_sid=%d(0x%04x)" %
             (info["profile"], info["source_sid"], info["hidden_pid"],
              info["inner_sid"], info["inner_sid"]))

    def close(self, reason="close", keep_kernel=False):
        if self.sock is not None:
            try:
                self.sock.close()
            except Exception:
                pass
            _log("CA socket closed reason=%s active=%s" % (reason, self.active_key))
        self.sock = None
        self.active_key = None
        self.active_inner_sid = None
        if not keep_kernel:
            self._disarm_kernel(reason)

    def _release_ca_socket_keep_kernel(self, reason="bootstrap complete"):
        if self.sock is not None:
            try:
                self.sock.close()
            except Exception:
                pass
            _log("CA bootstrap socket released reason=%s active=%s; kernel selector/helper hold preserved" %
                 (reason, self.active_key))
        self.sock = None
        # Keep active_key/active_inner_sid as the selected carrier/service
        # identity even though there is no persistent camd.socket owner.

    def _wait_cw_ready_and_release(self, info, ready_before):
        deadline = time.time() + CA_BOOTSTRAP_WAIT
        while time.time() < deadline:
            ready_now = _read_int(PARAM_FORCE_READY, ready_before)
            if ready_now > ready_before:
                self._release_ca_socket_keep_kernel(
                    "CW-ready hidden_pid=%d ready_hits=%d->%d" %
                    (info["hidden_pid"], ready_before, ready_now))
                return True
            time.sleep(CA_BOOTSTRAP_POLL)
        _log("CA bootstrap keep-open: no fresh CW-ready within %.2fs hidden_pid=%d; safety fallback preserves old behavior" %
             (CA_BOOTSTRAP_WAIT, info["hidden_pid"]))
        return False

    def _resolve(self, ref):
        mapping = _load_bouquet_map()
        cref = _canonical_ref(ref)
        rec = mapping.get(cref)
        if rec is None:
            return None
        pid = int(rec.get("hidden_pid", -1))
        profile = None
        source_sid = None
        outer_pmt_pid = None

        # New scans carry the entire userspace tuple in map v2.
        if all(k in rec for k in ("profile", "source_sid", "outer_pmt_pid")):
            profile = find_profile(rec["profile"])
            source_sid = int(rec["source_sid"])
            outer_pmt_pid = int(rec["outer_pmt_pid"])
            if profile is None:
                _log("profile %r from map is not present in abertis_config.py" % rec["profile"])
                return None
        else:
            # Compatibility only: an old PID-only map is accepted when that
            # PID is unique in the current userspace configuration.
            candidates = self.pid_map.get(pid, [])
            if len(candidates) != 1:
                _log("PID-only old map is ambiguous/missing ref=%s hidden_pid=%d candidates=%d; rescan with v6.0" %
                     (cref, pid, len(candidates)))
                return None
            source_sid, outer_pmt_pid, profile = candidates[0]

        source_ref = self.find_source_ref(source_sid, profile[1])
        if not source_ref:
            _log("cannot resolve outer source profile=%s sid=%d pid=%d" %
                 (profile[0], source_sid, pid))
            return None
        inner = _parse_ref(cref)
        outer = _parse_ref(source_ref)
        if not inner or not outer:
            _log("cannot parse service refs inner=%s outer=%s" % (cref, source_ref))
            return None
        return {
            "inner_ref": cref,
            "inner_sid": int(inner["sid"]),
            "hidden_pid": pid,
            "source_sid": int(source_sid),
            "outer_pmt_pid": int(outer_pmt_pid),
            "profile": profile[0],
            "source_ref": source_ref,
            "namespace": outer["ns"],
            "tsid": outer["tsid"],
            "onid": outer["onid"],
        }

    def inject(self, ref, force=False):
        info = self._resolve(ref)
        if not info:
            self.close("non-Abertis service")
            return "Not an Abertis mapped service."
        key = (info["source_sid"], info["hidden_pid"], info["outer_pmt_pid"], info["namespace"], info["tsid"], info["onid"])
        if self.sock is not None and self.active_key == key and not force:
            # IMPORTANT: the OSCam CA context is identical for every inner
            # service carried by this hidden PID, but the child-mux selector
            # is not.  v6.0 returned here and left the first inner SID armed,
            # so every later zap inside the same carrier could resolve to the
            # same programme.  Re-arm only the generic kernel selector while
            # preserving the already-working camd.socket/CW.
            new_inner_sid = int(info["inner_sid"])
            if self.active_inner_sid != new_inner_sid:
                old_inner_sid = self.active_inner_sid
                self._arm_kernel(info)
                self.active_inner_sid = new_inner_sid
                _log("GENERIC_PIPE same-CA service rearm hidden_pid=%d old_inner_sid=%s new_inner_sid=%d(0x%04x); OSCam socket/CW preserved" %
                     (info["hidden_pid"], str(old_inner_sid), new_inner_sid, new_inner_sid))
                return "Hidden CA kept; child service re-armed: %s inner SID %d" % (
                    info["profile"], new_inner_sid)
            return "Hidden CA already active: %s SID %d PID %d inner SID %d" % (
                info["profile"], info["source_sid"], info["hidden_pid"],
                new_inner_sid)

        self.close("replace hidden CA", keep_kernel=True)
        self._arm_kernel(info)
        ready_before = _read_int(PARAM_FORCE_READY, 0)
        packet = build_capmt(info["source_sid"], info["hidden_pid"],
                             info["namespace"], info["tsid"], info["onid"],
                             pmt_pid=info["outer_pmt_pid"])
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        try:
            s.settimeout(2.0)
            s.connect(SOCKET_PATH)
            s.sendall(packet)
            # Keep the connection open.  OSCam old camd.socket mode treats one
            # socket as one subscribed channel; close tears this CA context down.
            s.settimeout(None)
        except Exception:
            try:
                s.close()
            except Exception:
                pass
            self._disarm_kernel("CA inject failed")
            raise
        self.sock = s
        self.active_key = key
        self.active_inner_sid = int(info["inner_sid"])
        self.bootstrap_ready_before = ready_before
        pmt_pid = int(info["outer_pmt_pid"]) & 0x1FFF
        _log("INJECT inner=%s profile=%s source_sid=%d(0x%04x) hidden_pid=%d(0x%04x) pmt_pid=%d(0x%04x) ca_device=%d demux=%d ns=0x%08x tsid=0x%04x onid=0x%04x bytes=%d" %
             (info["inner_ref"], info["profile"], info["source_sid"], info["source_sid"],
              info["hidden_pid"], info["hidden_pid"], pmt_pid, pmt_pid, CA_DEVICE, DEMUX,
              info["namespace"], info["tsid"], info["onid"], len(packet)))
        _log("CAPMT " + _hex(packet))
        return "Hidden CA injected: %s outer SID %d / PID %d" % (
            info["profile"], info["source_sid"], info["hidden_pid"])

    def install(self):
        if self.installed:
            return
        nav = self.session.nav
        # Instance-level closures deliberately avoid touching Navigation.py or
        # any Enigma2 C++ object.  No polling/event watcher is installed.
        self.original_play = nav.playService
        self.original_stop = nav.stopService
        manager = self

        def play_wrapper(ref, *args, **kwargs):
            # Scan ownership is explicit.  The scanner publishes runtime_mode=1
            # and the current source SID/hidden PID itself.  The OUTER source
            # service is intentionally not present in the inner service map, so
            # resolving it as an ordinary foreground zap would disarm the pipe.
            if manager.scanner_owned:
                _log("SCAN_OWNER play passthrough ref=%s; preserve generic-pipe selector" %
                     _canonical_ref(ref))
                return manager.original_play(ref, *args, **kwargs)

            # Prime OSCam BEFORE the normal Enigma2 tune.  Fixed BISS uses a
            # synthetic ECM, so OSCam can program CA_SET_PID/CW immediately;
            # the ~150 ms frontend tune then gives the driver time to see the
            # selected hidden PID as CW-ready on its first section start.
            info = manager._resolve(ref)
            if info:
                try:
                    manager.inject(ref)
                    # Fixed BISS CA_PMT is resolved without waiting for ECM
                    # traffic.  Give OSCam/CA_SET_PID a short head start so
                    # V13.17 can suppress the very first outer PAT/PMT feed
                    # without waiting forever for a second section request.
                    time.sleep(CHILD_MUX_PRIME_DELAY)
                except Exception as e:
                    manager._disarm_kernel("pre-tune inject failed")
                    _log("pre-tune inject failed ref=%s error=%s" % (_canonical_ref(ref), e))
            else:
                manager.close("non-Abertis playService")
                return manager.original_play(ref, *args, **kwargs)

            # Let normal Enigma2 start the INNER service first.  Then wait only
            # until the generic driver reports a fresh CW-ready observation and
            # release the synthetic outer CA owner.  If readiness is not seen
            # within the bounded window, keep the socket open as a safety
            # fallback (v6.1 behavior).
            ret = manager.original_play(ref, *args, **kwargs)
            if manager.sock is not None:
                manager._wait_cw_ready_and_release(info, manager.bootstrap_ready_before)
            return ret

        def stop_wrapper(*args, **kwargs):
            if manager.scanner_owned:
                _log("SCAN_OWNER stop passthrough; preserve generic-pipe selector/hold")
                return manager.original_stop(*args, **kwargs)
            manager.close("Enigma2 stopService")
            return manager.original_stop(*args, **kwargs)

        nav.playService = play_wrapper
        nav.stopService = stop_wrapper
        self.installed = True
        _log("v6.2.1 hidden CA scanner-safe bootstrap/generic-pipe hook installed; all carrier values are userspace-configured; mapped_services=%d" %
             len(_load_bouquet_map()))


def install(session, find_source_ref, profiles):
    global _MANAGER
    if _MANAGER is not None:
        # A GUI restart creates a new Navigation/session object; replace stale
        # state instead of trying to reuse a wrapper tied to the old object.
        if _MANAGER.session is session:
            if not _MANAGER.installed:
                _MANAGER.install()
            return _MANAGER
        try:
            _MANAGER.close("session replaced")
        except Exception:
            pass
    _MANAGER = HiddenCAManager(session, find_source_ref, profiles)
    _MANAGER.install()
    return _MANAGER


def scanner_enter(session):
    """Temporarily give AbertisScanRunner ownership of nav play/stop calls."""
    if _MANAGER is None or _MANAGER.session is not session:
        return False
    if _MANAGER.scanner_owned:
        return True
    _MANAGER.close("scanner enter")
    _MANAGER.scanner_owned = True
    _log("SCAN_OWNER enter; scanner controls generic-pipe selector")
    return True


def scanner_leave(session):
    """Return Navigation ownership to normal foreground hidden-CA handling."""
    if _MANAGER is None or _MANAGER.session is not session:
        return False
    if not _MANAGER.scanner_owned:
        return True
    _MANAGER.scanner_owned = False
    _log("SCAN_OWNER leave; foreground hidden-CA hook restored")
    return True


def inject_current(session):
    if _MANAGER is None or _MANAGER.session is not session:
        return "Hidden CA hook is not installed for this Enigma2 session."
    try:
        ref = session.nav.getCurrentlyPlayingServiceOrGroup()
    except Exception as e:
        return "Cannot read current service: %s" % e
    if not ref:
        return "No current service."
    try:
        return _MANAGER.inject(ref, force=True) + "\nLog: " + LOGFILE
    except Exception as e:
        _log("manual inject failed: %s" % e)
        return "Hidden CA injection failed: %s\nLog: %s" % (e, LOGFILE)


def selftest():
    # Use the first userspace-configured carrier; no carrier tuple is duplicated
    # in this module. Namespace/TSID/ONID below are harmless wire-test values.
    from .abertis_config import PROFILES
    profile = PROFILES[0]
    source_sid, hidden_pid, pmt_pid = carrier_values(profile[4][0])
    packet = build_capmt(source_sid, hidden_pid, 0x01020304, 0x1234, 0x5678,
                         pmt_pid=pmt_pid)
    b = bytearray(packet)
    assert b[:6] == bytearray([0x9F, 0x80, 0x32, 0x82, 0x00, len(b) - 6])
    assert b[6] == 0x03
    assert ((b[7] << 8) | b[8]) == source_sid
    pil = ((b[10] & 0x0F) << 8) | b[11]
    assert pil > 1
    program = b[13:13 + pil - 1]
    ecm_pid = int(FAKE_ECM_PID) & 0x1FFF
    ca_desc = bytearray([0x09, 0x04] + _u16(CAID) +
                        [0xE0 | ((ecm_pid >> 8) & 0x1F), ecm_pid & 0xFF])
    assert ca_desc in program
    pos = 12 + pil
    assert b[pos] == 0x06
    assert (((b[pos + 1] & 0x1F) << 8) | b[pos + 2]) == hidden_pid
    assert bytearray([0x84, 0x02] + _u16(pmt_pid)) in program
    assert bytearray([0x82]) not in program
    print("v6.2.1 scanner-safe generic CA_PMT selftest OK")
    print(_hex(packet))


if __name__ == "__main__":
    selftest()
