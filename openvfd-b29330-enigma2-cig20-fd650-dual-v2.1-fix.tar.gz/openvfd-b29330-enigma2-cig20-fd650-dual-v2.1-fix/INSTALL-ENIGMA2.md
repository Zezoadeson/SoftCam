# OpenVFD FD650 + Enigma2 channel-number integration

This tree is based on the supplied OpenVFD source and adds:

* `/etc/vfd.conf` as the only runtime configuration file used by the startup script.
* `OpenVFDService` text FIFO commands: `channel=N` and `clock`.
* An Enigma2 SystemPlugin that updates the display after every service zap.
* A DreamOne/Amlogic FD650 sample configuration using GPIO DATA=76 and CLK=77.

## Device tree

The driver still needs a platform device to bind to. Add this at the DTS root:

    openvfd {
        compatible = "open,vfd";
        status = "okay";
    };

GPIOs are intentionally not placed in the DT node; `/etc/vfd.conf` supplies them as module parameters.
Remove/disable the previous `i2c-gpio` / `fdhisi,fd650` tm16xx node so the same GPIOs are not claimed twice.

## Build

Kernel module, using the exact prepared kernel tree and matching Module.symvers:

    make -C "$KDIR" \
        M="$PWD/driver" \
        ARCH=arm64 \
        CROSS_COMPILE="$CROSS_COMPILE" \
        modules

Build OpenVFDService with the Enigma2/rootfs userspace cross compiler, or natively on the target if a compiler is available:

    ${CC:-gcc} -Wall -O2 -o OpenVFDService OpenVFDService.c -lm -lpthread

## Install

Suggested files:

    /lib/modules/$(uname -r)/extra/openvfd.ko
    /usr/bin/OpenVFDService
    /usr/bin/openvfd-channel
    /usr/bin/openvfd-clock
    /etc/init.d/openvfd
    /etc/vfd.conf
    /usr/lib/enigma2/python/Plugins/SystemPlugins/OpenVFDChannel/__init__.py
    /usr/lib/enigma2/python/Plugins/SystemPlugins/OpenVFDChannel/plugin.py

Copy them from this source tree:

    install -m 755 OpenVFDService /usr/bin/OpenVFDService
    install -m 755 scripts/openvfd-channel /usr/bin/openvfd-channel
    install -m 755 scripts/openvfd-clock /usr/bin/openvfd-clock
    install -m 755 scripts/openvfd-init /etc/init.d/openvfd
    install -m 644 vfd.conf /etc/vfd.conf
    mkdir -p /usr/lib/enigma2/python/Plugins/SystemPlugins/OpenVFDChannel
    cp -a enigma2/OpenVFDChannel/. /usr/lib/enigma2/python/Plugins/SystemPlugins/OpenVFDChannel/

After copying the kernel module, run depmod if it is installed:

    depmod -a

Then:

    /etc/init.d/openvfd start

Manual display test:

    openvfd-channel 123

The display should show channel 123. Return to clock mode with:

    openvfd-clock

Restart Enigma2 after installing the plugin:

    init 3
    init 4

When a numbered live service starts, the plugin sends `channel=<number>` to `/tmp/openvfd_service`.

## Channel formatting and status LEDs

This revision renders channel numbers with four digits and leading zeroes:

    1    -> 0001
    23   -> 0023
    123  -> 0123
    1234 -> 1234

The Enigma2 SystemPlugin also controls two FD650 status bits:

* red LED: always on
* green LED: on whenever Enigma2's DVB `signalQuality` is non-zero and at
  or above `vfd_green_snr_threshold`

Settings live in `/etc/vfd.conf`:

    vfd_red_led_bit='0'
    vfd_green_led_bit='1'
    vfd_green_snr_threshold='1'
    vfd_snr_poll_ms='500'

If the physical red/green LEDs are not bits 0/1, run:

    /usr/bin/openvfd-led-scan

and watch which bit lights each LED, then update the two bit settings.

## DreamOne FD650 physical LED mapping

Direct hardware scanning established that the two far-left LEDs are not on
the FD650 icon byte. They use the eighth segment of two digit grids:

* lower red LED: digit grid 4, segment `0x80`
* upper green/amber LED: digit grid 1, segment `0x80`

The patched `fd650_write_display_data()` maps OpenVFD logical status bit 0
to red and logical status bit 1 to green. The Enigma2 plugin keeps red set
and toggles green from DVB signal quality, then forces a channel redraw so
the LED state is applied immediately.
