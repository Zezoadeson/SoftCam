# -*- coding: utf-8 -*-
from __future__ import print_function

import os
import struct

from enigma import eTimer, iPlayableService, iFrontendInformation
from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigListScreen
from Components.config import (
    config,
    configfile,
    ConfigSubsection,
    ConfigSelection,
    ConfigText,
    getConfigListEntry,
)
from Components.Sources.StaticText import StaticText
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen


FIFO = "/tmp/openvfd_service"
VFD_CONF = "/etc/vfd.conf"
LED_CMD = "/sys/class/leds/openvfd/led_cmd"
BRIGHTNESS = "/sys/class/leds/openvfd/brightness"

# _IOW('M', 7, int) from openvfd_drv.h
VFD_IOC_STATUS_LED = 0x40044D07

_instance = None


# Persistent Enigma2 settings.  Keep existing objects if the plugin is
# reloaded from the Plugins browser so current/saved values are not reset.
if not hasattr(config.plugins, "openvfd"):
    config.plugins.openvfd = ConfigSubsection()
if not hasattr(config.plugins.openvfd, "mode"):
    config.plugins.openvfd.mode = ConfigSelection(
        default="channel",
        choices=[
            ("channel", "Channel name"),
            ("clock", "Clock"),
            ("text", "Custom text"),
        ],
    )
if not hasattr(config.plugins.openvfd, "custom_text"):
    config.plugins.openvfd.custom_text = ConfigText(default="TIGER", fixed_size=False)
if not hasattr(config.plugins.openvfd, "brightness"):
    config.plugins.openvfd.brightness = ConfigSelection(
        default="6",
        choices=[(str(x), str(x)) for x in range(8)],
    )


def _read_shell_int(name, default):
    """Read a simple integer shell assignment from /etc/vfd.conf."""
    try:
        f = open(VFD_CONF, "r")
        try:
            prefix = name + "="
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or not line.startswith(prefix):
                    continue
                value = line[len(prefix):].strip()
                if len(value) >= 2 and value[0] in ("'", '"') and value[-1] == value[0]:
                    value = value[1:-1]
                try:
                    return int(value, 0)
                except Exception:
                    return default
        finally:
            f.close()
    except Exception:
        pass
    return default


class OpenVFDChannelSync(object):
    """Synchronize OpenVFD display mode, brightness and DVB signal LEDs."""

    def __init__(self, session):
        self.session = session

        self.channel_timer = eTimer()
        self.channel_timer_conn = None
        self.snr_timer = eTimer()
        self.snr_timer_conn = None

        self.last_channel = None
        self.last_title = None
        self.last_led_mask = None
        self.last_snr_percent = None
        self.scan_display_active = False
        self.last_scan_snr = None

        self.red_bit = _read_shell_int("vfd_red_led_bit", 0)
        self.green_bit = _read_shell_int("vfd_green_led_bit", 1)
        self.snr_threshold = _read_shell_int("vfd_green_snr_threshold", 1)
        self.snr_poll_ms = _read_shell_int("vfd_snr_poll_ms", 500)
        self.show_channel_name = bool(_read_shell_int("vfd_show_channel_name", 0))
        self.cig20_signal_bars = bool(_read_shell_int("vfd_cig20_signal_bars", 0))

        if self.red_bit < 0 or self.red_bit > 7:
            self.red_bit = 0
        if self.green_bit < 0 or self.green_bit > 7:
            self.green_bit = 1
        if self.snr_threshold < 0:
            self.snr_threshold = 0
        if self.snr_threshold > 100:
            self.snr_threshold = 100
        if self.snr_poll_ms < 200:
            self.snr_poll_ms = 200

        try:
            self.channel_timer_conn = self.channel_timer.timeout.connect(self.update_channel)
        except Exception:
            self.channel_timer.callback.append(self.update_channel)

        try:
            self.snr_timer_conn = self.snr_timer.timeout.connect(self.update_snr)
        except Exception:
            self.snr_timer.callback.append(self.update_snr)

        try:
            self.session.nav.event.append(self.service_event)
        except Exception as err:
            print("[OpenVFD] unable to attach nav event: %s" % err)

        # Apply the saved front-panel mode and brightness when Enigma2 starts.
        self.apply_settings()

        # Enigma2/InfoBar may not be fully ready at WHERE_SESSIONSTART.
        if self.get_mode() == "channel":
            self.schedule_channel(1500)
        self.schedule_snr(500)

        print("[OpenVFD] mode=%s brightness=%d channel-name=%s cig20-bars=%s red=%d green=%d SNR-threshold=%d%%" %
              (self.get_mode(), self.get_brightness(),
               "yes" if self.show_channel_name else "no",
               "yes" if self.cig20_signal_bars else "no",
               self.red_bit, self.green_bit, self.snr_threshold))

    def stop(self):
        try:
            self.channel_timer.stop()
        except Exception:
            pass
        try:
            self.snr_timer.stop()
        except Exception:
            pass
        try:
            self.session.nav.event.remove(self.service_event)
        except Exception:
            pass

        # Clear CIG20 bars, or keep the established FD650 red/green behavior.
        if self.cig20_signal_bars:
            self.send_signal_bars(0)
        else:
            self.set_leds(False)

    def get_mode(self):
        try:
            mode = config.plugins.openvfd.mode.value
        except Exception:
            mode = "channel"
        if mode not in ("channel", "clock", "text"):
            mode = "channel"
        return mode

    def get_brightness(self):
        try:
            level = int(config.plugins.openvfd.brightness.value)
        except Exception:
            level = 6
        if level < 0:
            level = 0
        if level > 7:
            level = 7
        return level

    def set_brightness(self, level=None):
        if level is None:
            level = self.get_brightness()

        try:
            level = int(level)
        except Exception:
            level = 6

        if level < 0:
            level = 0
        if level > 7:
            level = 7

        try:
            f = open(BRIGHTNESS, "w")
            try:
                f.write("%d\n" % level)
            finally:
                f.close()
            print("[OpenVFD] brightness=%d" % level)
            return True
        except Exception as err:
            print("[OpenVFD] unable to set brightness: %s" % err)
            return False

    def send_fifo(self, command):
        if not command.endswith("\n"):
            command += "\n"

        fd = None
        try:
            fd = os.open(FIFO, os.O_WRONLY | os.O_NONBLOCK)
            os.write(fd, command.encode("ascii"))
            return True
        except OSError:
            return False
        finally:
            if fd is not None:
                try:
                    os.close(fd)
                except Exception:
                    pass

    def send_clock(self):
        return self.send_fifo("clock")

    def schedule_channel(self, ms=250):
        try:
            self.channel_timer.start(ms, True)
        except Exception as err:
            print("[OpenVFD] channel timer error: %s" % err)

    def schedule_snr(self, ms=None):
        if ms is None:
            ms = self.snr_poll_ms
        try:
            self.snr_timer.start(ms, True)
        except Exception as err:
            print("[OpenVFD] SNR timer error: %s" % err)

    def service_event(self, event):
        if event in (iPlayableService.evStart,
                     iPlayableService.evUpdatedInfo,
                     iPlayableService.evTunedIn):
            if self.get_mode() == "channel":
                # Give the service list/frontend a moment to update.
                self.schedule_channel(250)
            elif self.get_mode() == "clock":
                self.send_clock()
            else:
                self.send_custom_text()
            self.schedule_snr(250)

        elif event == iPlayableService.evEnd:
            self.last_channel = None
            self.last_title = None
            if self.get_mode() == "clock":
                self.send_clock()
            elif self.get_mode() == "text":
                self.send_custom_text()
            if self.cig20_signal_bars:
                self.send_signal_bars(0)
            else:
                self.set_leds(False)

    def get_channel_number(self):
        number = 0

        try:
            ref = self.session.nav.getCurrentlyPlayingServiceReference()
            if ref is not None and hasattr(ref, "getChannelNum"):
                number = int(ref.getChannelNum())
        except Exception:
            number = 0

        # Some images expose bouquet numbering more reliably through InfoBar.
        if number <= 0:
            try:
                from Screens.InfoBar import InfoBar
                infobar = InfoBar.instance
                if infobar is not None and getattr(infobar, "servicelist", None) is not None:
                    ref = infobar.servicelist.getCurrentSelection()
                    if ref is not None and hasattr(ref, "getChannelNum"):
                        number = int(ref.getChannelNum())
            except Exception:
                number = 0

        return number

    def get_channel_name(self):
        """Return a front-panel-safe ASCII service name for CIG20."""
        name = ""
        try:
            service = self.session.nav.getCurrentService()
            info = service and service.info()
            if info is not None and hasattr(info, "getName"):
                name = info.getName() or ""
        except Exception:
            name = ""

        if not name:
            try:
                ref = self.session.nav.getCurrentlyPlayingServiceReference()
                if ref is not None and hasattr(ref, "getName"):
                    name = ref.getName() or ""
            except Exception:
                name = ""

        try:
            # Enigma service names can contain formatting/control bytes. The
            # recovered Tiger CIG20 font is ASCII, so keep printable ASCII and
            # replace everything else with spaces rather than feeding raw UTF-8
            # bytes to the 16-segment table.
            if not isinstance(name, str):
                name = str(name)
            out = []
            for ch in name:
                try:
                    code = ord(ch)
                except Exception:
                    continue
                if 32 <= code <= 126:
                    out.append(ch)
                elif code in (9, 10, 13):
                    out.append(" ")
            name = "".join(out)
            name = " ".join(name.split())
        except Exception:
            name = ""

        return name.strip()

    def send_title(self, title):
        if not title:
            return False
        return self.send_fifo("title=%s" % title)

    def get_custom_text(self):
        try:
            text = config.plugins.openvfd.custom_text.value or ""
        except Exception:
            text = ""
        # Keep FIFO commands single-line and front-panel safe.
        text = " ".join(str(text).replace("\r", " ").replace("\n", " ").split())
        return text

    def send_custom_text(self):
        text = self.get_custom_text()
        return self.send_title(text if text else " ")

    def send_secondary_green(self, state):
        return self.send_fifo("green=%d" % (1 if state else 0))

    def send_channel(self, number):
        if number <= 0 or number > 65535:
            return False

        # The kernel's seg7 formatter renders this as exactly four digits:
        # 1 -> 0001, 23 -> 0023, 123 -> 0123.
        return self.send_fifo("channel=%d" % number)

    def send_signal_bars(self, percent):
        """Update only the verified Tiger CIG20 signal meter in RAM slot 12."""
        try:
            percent = int(percent)
        except Exception:
            percent = 0
        if percent < 0:
            percent = 0
        if percent > 100:
            percent = 100
        return self.send_fifo("snr=%d" % percent)

    def send_snr(self, percent):
        """Temporary scan/finder SNR display, with native CIG20 bars when enabled."""
        try:
            percent = int(percent)
        except Exception:
            percent = 0
        if percent < 0:
            percent = 0
        if percent > 100:
            percent = 100

        if self.cig20_signal_bars:
            # Keep the bar graph updated and use readable alphanumeric text
            # instead of the legacy four-digit FD650 formatter.
            self.send_signal_bars(percent)
            return self.send_fifo("title=SNR %d%%" % percent)

        # Legacy FD650 behavior: 73% -> 0073.
        return self.send_fifo("channel=%d" % percent)

    def get_service_scan_dialog(self):
        """Return Enigma2's ServiceScan screen if it is currently open."""
        dialogs = []

        try:
            dialog = getattr(self.session, "current_dialog", None)
            if dialog is not None:
                dialogs.append(dialog)
        except Exception:
            pass

        # During a scan Enigma2 can temporarily put another dialog (for
        # example a message box) on top of ServiceScan.  Check the dialog
        # stack too so we can still find the scan screen underneath it.
        try:
            for item in getattr(self.session, "dialog_stack", []) or []:
                dialog = item
                if isinstance(item, (tuple, list)) and item:
                    dialog = item[0]
                if dialog is not None:
                    dialogs.append(dialog)
        except Exception:
            pass

        for dialog in dialogs:
            try:
                cls = dialog.__class__
                name = getattr(cls, "__name__", "")
                module = getattr(cls, "__module__", "")
                if name == "ServiceScan" or module == "Screens.ServiceScan":
                    return dialog
            except Exception:
                pass

        return None

    def get_service_scan_engine(self):
        """Return the running eComponentScan instance, or None when not scanning."""
        dialog = self.get_service_scan_dialog()
        if dialog is None:
            return None

        # Newer Enigma2: Screens.ServiceScan owns eComponentScan directly as
        # self.scan and exposes RUNNING/state on the screen.
        try:
            engine = getattr(dialog, "scan", None)
            if engine is not None and hasattr(engine, "getFrontend"):
                running_const = getattr(dialog, "RUNNING", None)
                state = getattr(dialog, "state", running_const)
                if running_const is None or state == running_const:
                    return engine
        except Exception:
            pass

        # Older/Dreambox-style Enigma2: Screens.ServiceScan contains a
        # Components.ServiceScan object under self["scan"].  That component
        # owns the eComponentScan instance as .scan and has Running/state.
        try:
            component = dialog["scan"]
            running_const = getattr(component, "Running", None)
            state = getattr(component, "state", running_const)
            if running_const is not None and state != running_const:
                return None
            engine = getattr(component, "scan", None)
            if engine is not None and hasattr(engine, "getFrontend"):
                return engine
        except Exception:
            pass

        return None

    def is_service_scan_active(self):
        # "Active" deliberately means the tuner is actually searching, not
        # merely that the completed ServiceScan results screen is still open.
        return self.get_service_scan_engine() is not None

    def get_signal_finder_dialog(self):
        """Return the Satfinder/Signal finder screen while it is open."""
        dialogs = []

        try:
            dialog = getattr(self.session, "current_dialog", None)
            if dialog is not None:
                dialogs.append(dialog)
        except Exception:
            pass

        # Keep recognising Signal finder even if a temporary message box is
        # displayed over it.  This mirrors the ServiceScan handling above.
        try:
            for item in getattr(self.session, "dialog_stack", []) or []:
                dialog = item
                if isinstance(item, (tuple, list)) and item:
                    dialog = item[0]
                if dialog is not None:
                    dialogs.append(dialog)
        except Exception:
            pass

        for dialog in dialogs:
            try:
                cls = dialog.__class__
                name = getattr(cls, "__name__", "")
                module = getattr(cls, "__module__", "")

                # Standard Enigma2/OpenATV/OpenViX signal finder is named
                # Satfinder (or SatfinderExtra on some images) and lives in
                # Plugins.SystemPlugins.Satfinder.plugin.  Accept equivalent
                # SignalFinder names used by a few other images too.
                lname = str(name).lower()
                lmodule = str(module).lower()
                if (lname in ("satfinder", "satfinderextra", "signalfinder", "signalfinderextra") or
                        "satfinder" in lmodule or "signalfinder" in lmodule):
                    return dialog
            except Exception:
                pass

        return None

    def is_signal_finder_active(self):
        # Unlike ServiceScan, Signal finder should own the VFD for the entire
        # time its screen is open, including the short frontend-allocation
        # period where self.frontend may still be None.
        return self.get_signal_finder_dialog() is not None

    def get_signal_finder_snr_percent(self):
        """Read SNR from the frontend allocated by Satfinder/Signal finder."""
        dialog = self.get_signal_finder_dialog()
        if dialog is None:
            return None

        try:
            frontend = getattr(dialog, "frontend", None)
            if frontend is None:
                return 0

            status = {}
            frontend.getFrontendStatus(status)

            raw = status.get("tuner_signal_quality")
            if raw is None:
                raw = status.get("snr")
            if raw is None:
                return 0

            raw = int(raw)
            if raw <= 0:
                return 0
            if raw > 65535:
                raw = 65535

            return int((raw * 100 + 32767) // 65535)
        except Exception:
            return 0

    def is_temporary_snr_display_active(self):
        return self.is_service_scan_active() or self.is_signal_finder_active()

    def get_temporary_snr_percent(self):
        if self.is_service_scan_active():
            value = self.get_scan_snr_percent()
            return 0 if value is None else value

        if self.is_signal_finder_active():
            value = self.get_signal_finder_snr_percent()
            return 0 if value is None else value

        return None

    def refresh_display(self):
        """Re-send the selected display mode without changing the saved setting."""
        if self.is_temporary_snr_display_active():
            snr_percent = self.get_temporary_snr_percent()
            if snr_percent is None:
                snr_percent = 0
            self.scan_display_active = True
            self.last_scan_snr = snr_percent
            return self.send_snr(snr_percent)

        if self.get_mode() == "clock":
            return self.send_clock()
        if self.get_mode() == "text":
            return self.send_custom_text()

        number = self.get_channel_number()
        if number <= 0:
            number = self.last_channel or 0

        if self.show_channel_name:
            title = self.get_channel_name() or self.last_title or ""
            if title and self.send_title(title):
                self.last_title = title
                if number > 0:
                    self.last_channel = number
                return True

        if number > 0 and self.send_channel(number):
            self.last_channel = number
            self.last_title = None
            return True

        return False

    def apply_settings(self):
        """Apply current (saved or live-preview) Enigma2 settings immediately."""
        self.set_brightness()

        if self.get_mode() == "clock":
            try:
                self.channel_timer.stop()
            except Exception:
                pass
            self.send_clock()
        elif self.get_mode() == "text":
            try:
                self.channel_timer.stop()
            except Exception:
                pass
            self.send_custom_text()
        else:
            self.last_channel = None
            self.last_title = None
            self.refresh_display()
            self.schedule_channel(250)

        # CIG20 uses the verified native bar graph; FD650 keeps its LEDs.
        snr_percent = self.get_snr_percent()
        green_on = snr_percent >= self.snr_threshold and snr_percent > 0
        if self.cig20_signal_bars:
            self.send_signal_bars(snr_percent)
        else:
            self.set_leds(green_on)
        self.send_secondary_green(green_on)

        print("[OpenVFD] applied mode=%s brightness=%d" %
              (self.get_mode(), self.get_brightness()))

    def update_channel(self):
        # Never let a delayed channel-number update overwrite SNR while
        # Enigma2 is scanning or the Signal finder screen owns the frontend.
        if self.is_temporary_snr_display_active():
            return

        if self.get_mode() != "channel":
            return

        number = self.get_channel_number()
        if self.show_channel_name:
            title = self.get_channel_name()
            if title and (title != self.last_title or number != self.last_channel):
                if self.send_title(title):
                    self.last_title = title
                    if number > 0:
                        self.last_channel = number
                    print("[OpenVFD] title %s" % title)
                    return

        if number > 0 and number != self.last_channel:
            if self.send_channel(number):
                self.last_channel = number
                self.last_title = None
                print("[OpenVFD] channel %04d" % (number % 10000))

    def get_scan_snr_percent(self):
        """Read SNR from the frontend currently owned by ServiceScan."""
        engine = self.get_service_scan_engine()
        if engine is None:
            return None

        try:
            frontend = engine.getFrontend()
            if frontend is None:
                return 0

            status = {}
            frontend.getFrontendStatus(status)

            # Newer Enigma2 uses tuner_signal_quality.  Older images may
            # expose the same 0..65535 value as snr.
            raw = status.get("tuner_signal_quality")
            if raw is None:
                raw = status.get("snr")
            if raw is None:
                return 0

            raw = int(raw)
            if raw <= 0:
                return 0
            if raw > 65535:
                raw = 65535

            return int((raw * 100 + 32767) // 65535)
        except Exception:
            return 0

    def get_snr_percent(self):
        """
        Return Enigma2 DVB signalQuality as 0..100.

        iFrontendInformation.signalQuality is 0..65535. Non-DVB services
        normally have no frontendInfo(), so they naturally return 0 here.
        """
        try:
            service = self.session.nav.getCurrentService()
            feinfo = service and service.frontendInfo()
            if feinfo is None:
                return 0

            raw = int(feinfo.getFrontendInfo(iFrontendInformation.signalQuality))
            if raw <= 0:
                return 0
            if raw > 65535:
                raw = 65535

            return int((raw * 100 + 32767) // 65535)
        except Exception:
            return 0

    def write_led_mask(self, mask):
        mask &= 0xFF

        if mask == self.last_led_mask:
            return True

        fd = None
        try:
            # Use OpenVFD's LED-class sysfs command instead of opening
            # /dev/openvfd. Opening/closing /dev/openvfd toggles panel power
            # in this old V1.3.0 driver.
            fd = os.open(LED_CMD, os.O_WRONLY)
            payload = struct.pack("=ii", VFD_IOC_STATUS_LED, mask)
            os.write(fd, payload)
            self.last_led_mask = mask

            # V1.3.0 stores status_led_mask but does not immediately redraw.
            # Refresh whichever display mode the user selected.
            self.refresh_display()
            return True

        except OSError:
            return False

        finally:
            if fd is not None:
                try:
                    os.close(fd)
                except Exception:
                    pass

    def set_leds(self, green_on):
        # fix4+ kernel mapping:
        # bit 0 -> lower RED LED   -> FD650 digit grid 4 / segment 0x80
        # bit 1 -> upper GREEN LED -> FD650 digit grid 1 / segment 0x80
        red_mask = 1 << self.red_bit
        green_mask = (1 << self.green_bit) if green_on else 0
        return self.write_led_mask(red_mask | green_mask)

    def update_snr(self):
        try:
            scanning = self.is_service_scan_active()
            signal_finder = (not scanning and self.is_signal_finder_active())
            temporary_display = scanning or signal_finder

            if scanning:
                snr_percent = self.get_scan_snr_percent()
                if snr_percent is None:
                    snr_percent = 0
            elif signal_finder:
                snr_percent = self.get_signal_finder_snr_percent()
                if snr_percent is None:
                    snr_percent = 0
            else:
                snr_percent = self.get_snr_percent()

            green_on = snr_percent >= self.snr_threshold and snr_percent > 0
            if self.cig20_signal_bars:
                # This changes only slot 12, so channel-name scrolling is kept.
                if snr_percent != self.last_snr_percent:
                    self.send_signal_bars(snr_percent)
            else:
                self.set_leds(green_on)

            if snr_percent != self.last_snr_percent:
                self.send_secondary_green(green_on)

            if temporary_display:
                # While ServiceScan or Signal finder is active, replace the
                # normal channel/clock display with live SNR from that screen's
                # own frontend.
                if (not self.scan_display_active or
                        snr_percent != self.last_scan_snr):
                    if self.send_snr(snr_percent):
                        self.scan_display_active = True
                        self.last_scan_snr = snr_percent
                        source = "scan" if scanning else "signal finder"
                        print("[OpenVFD] %s SNR display %04d" %
                              (source, snr_percent))
            elif self.scan_display_active:
                # The temporary SNR owner has closed: immediately restore the
                # user's normal front-panel mode.
                self.scan_display_active = False
                self.last_scan_snr = None
                self.last_channel = None
                self.last_title = None
                self.refresh_display()
                print("[OpenVFD] scan/signal finder ended; normal display restored")

            if snr_percent != self.last_snr_percent:
                self.last_snr_percent = snr_percent
                print("[OpenVFD] SNR %d%% green=%s" %
                      (snr_percent, "on" if green_on else "off"))
        finally:
            self.schedule_snr()


class OpenVFDSetup(Screen, ConfigListScreen):
    """Simple Enigma2 setup screen for the DreamOne front panel."""

    skin = """
        <screen name="OpenVFDSetup" position="center,center" size="720,360"
                title="OpenVFD Front Panel">
            <widget name="config" position="30,35" size="660,220"
                    scrollbarMode="showOnDemand" />
            <widget source="key_red" render="Label"
                    position="30,290" size="180,40" font="Regular;24"
                    halign="center" valign="center"
                    foregroundColor="#ffffff" backgroundColor="#9f1313" transparent="0" />
            <widget source="key_green" render="Label"
                    position="510,290" size="180,40" font="Regular;24"
                    halign="center" valign="center"
                    foregroundColor="#ffffff" backgroundColor="#1f771f" transparent="0" />
        </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)

        self["key_red"] = StaticText("Cancel")
        self["key_green"] = StaticText("Save")

        entries = [
            getConfigListEntry("Display mode", config.plugins.openvfd.mode),
            getConfigListEntry("Custom text", config.plugins.openvfd.custom_text),
            getConfigListEntry("Brightness", config.plugins.openvfd.brightness),
        ]

        ConfigListScreen.__init__(self, entries, session=session)

        self["actions"] = ActionMap(
            ["SetupActions", "ColorActions"],
            {
                "save": self.keySave,
                "green": self.keySave,
                "cancel": self.keyCancel,
                "red": self.keyCancel,
                "left": self.keyLeft,
                "right": self.keyRight,
            },
            -2,
        )

        self.setTitle("OpenVFD Front Panel")

    def apply_preview(self):
        if _instance is not None:
            _instance.apply_settings()

    def keyLeft(self):
        ConfigListScreen.keyLeft(self)
        self.apply_preview()

    def keyRight(self):
        ConfigListScreen.keyRight(self)
        self.apply_preview()

    def keySave(self):
        config.plugins.openvfd.mode.save()
        config.plugins.openvfd.custom_text.save()
        config.plugins.openvfd.brightness.save()
        configfile.save()

        if _instance is not None:
            _instance.apply_settings()

        self.close()

    def keyCancel(self):
        # ConfigElement.cancel() restores the last saved value.
        config.plugins.openvfd.mode.cancel()
        config.plugins.openvfd.custom_text.cancel()
        config.plugins.openvfd.brightness.cancel()

        if _instance is not None:
            _instance.apply_settings()

        self.close()


def open_setup(session, **kwargs):
    session.open(OpenVFDSetup)


def sessionstart(reason, **kwargs):
    global _instance

    if reason == 0:
        session = kwargs.get("session")
        if session is not None and _instance is None:
            _instance = OpenVFDChannelSync(session)

    elif _instance is not None:
        _instance.stop()
        _instance = None


def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="OpenVFD Front Panel",
            description="Front-panel mode, brightness and DVB signal LEDs",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            fnc=open_setup,
        ),
        PluginDescriptor(
            name="OpenVFD Front Panel",
            description="Apply front-panel settings and synchronize DVB signal LEDs",
            where=PluginDescriptor.WHERE_SESSIONSTART,
            fnc=sessionstart,
        ),
    ]
