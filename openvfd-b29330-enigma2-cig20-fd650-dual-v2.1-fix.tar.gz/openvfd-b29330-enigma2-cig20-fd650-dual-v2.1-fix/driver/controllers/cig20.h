#ifndef __CIG20_H__
#define __CIG20_H__

#include "controller.h"

struct controller_interface *init_cig20(struct vfd_dev *dev);
unsigned char cig20_set_status_mask(unsigned char mask);
unsigned char cig20_set_signal_percent(unsigned int percent);

#endif
