# Enigma2 Dual CIG20 + FD650 clock

Version: `V1.3.0-e2-fd650-cig20-dual-clock`

This branch is based directly on the working Enigma2 CIG20 live-signal V3 tree.
The primary CIG20 path is intentionally unchanged: channel-name scrolling,
`title=`, `snr=` / `signal=`, and the verified slot-12 signal meter remain on
the same code path.

The only functional addition is a secondary FD650 controller:

- Primary CIG20: GPIOAO_4 / AO6 / AO7 / AO8.
- Secondary FD650: GPIO65 CLK / GPIO64 DAT.
- `vfd_display_type.reserved bit0` enables dual mode.
- `OpenVFDService` sends the secondary display local 24-hour time through
  `VFD_IOC_SECONDARY_CLOCK` while leaving primary display data untouched.
- The FD650 never mirrors channel names or signal data; it is clock-only.

Install the matching `OpenVFDService` built from this tree together with the
new `openvfd.ko`.  If only the module is replaced while an older service is
kept, the secondary FD650 will initialize but will not receive time updates.

Build service example:

    make service CC=aarch64-linux-gnu-gcc

Use `vfd.conf_tiger-one-billion-v1-dual-cig20-fd650` as `/etc/vfd.conf`.
The existing `scripts/openvfd-init` already passes gpio1/gpio2, so no startup
script change is required.

Expected dmesg:

    OpenVFD: Version: V1.3.0-e2-fd650-cig20-dual-clock
    OpenVFD: Select CIG20/PT6393 controller
    OpenVFD: CIG20/PT6393 initialized: ...
    OpenVFD: Dual display enabled: primary CIG20/PT6393 + secondary FD650 clock ...
